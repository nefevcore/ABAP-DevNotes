sap.ui.define([
    "sap/ui/core/UIComponent",
    "cdm/model/models",
    "cdm/services/utils/ResourceManager"
], (UIComponent, models, ResourceManager) => {
    "use strict";

    return UIComponent.extend("cdm.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // enable routing
            this.getRouter().initialize();

            // 设置模型
            ResourceManager.initialize(this);
            ResourceManager.setImage("/logo", "/images/logo.png");
            ResourceManager.setImage("/background", "/images/bg.jpg");
            ResourceManager.setImage("/background1", "/images/bg1.png");
            ResourceManager.setImage("/background_S06", "/images/S06-bg.png");

            // 移除token信息
            this._removeUrlParameter("MYSAPSSO2");
        },

        _removeUrlParameter: function (paramKey) {
            // 为了实现单点登录，在URL上嵌入了cookie信息
            // 重复在GUI上启动页面的时候，由于无需登录，导致URL上保留了Cookie信息
            // 需要手工删除URL上的Cookie信息
            const url = new URL(window.location.href);
            url.searchParams.delete(paramKey);
            window.history.replaceState({}, document.title, url.href);
        },

        /**
         * 获取该应用路径
         * @returns 
         */
        getCdmModulePath: function () {
            return jQuery.sap.getModulePath("cdm");
        },

        getResourceManager: function () {
            return ResourceManager;
        }
    });
});