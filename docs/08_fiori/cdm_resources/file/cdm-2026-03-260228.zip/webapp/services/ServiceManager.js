sap.ui.define([
    "cdm/services/api/MonitorService",
], function (
    MonitorService
) {
    "use strict";

    return {
        /**
         * 创建通用监控服务
         * @param {sap.ui.model.Model} oDataModel 对应的OData模型
         * @returns {cdm.services.api.MonitorService} 服务实例
         */
        createMonitorService: function (oDataModel) {
            var oMonitorService = new MonitorService();
            oMonitorService.setDataModel(oDataModel);
            return oMonitorService;
        }
    };
});