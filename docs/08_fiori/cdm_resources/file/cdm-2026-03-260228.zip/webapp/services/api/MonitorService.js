sap.ui.define([
    "cdm/services/core/BaseService",
    "cdm/services/utils/ServiceUtil",
], function (
    BaseService,
    ServiceUtil
) {
    "use strict";

    return BaseService.extend("cdm.services.api.MonitorService", {
        /**
         * 获取组件信息
         * @param {any} componentId 组件ID
         * @returns {Promise}
         */
        getComponentOption: function (componentId) {
            var oRequestData = {
                "Uuid": ServiceUtil.getUUID(),
                "Action": "COMPONENT_OPTION",
                "Payload": componentId
            };

            return new Promise((resolve, reject) => {
                ServiceUtil.request(this.getDataModel(), "/ZFICOI_MONITOR_API", oRequestData)
                    .then((oData) => {
                        resolve(JSON.parse(oData.Payload));
                    })
                    .catch((oError) => {
                        reject(oError);
                    });
            });
        }
    });
});