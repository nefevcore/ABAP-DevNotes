sap.ui.define([
    "sap/ui/base/ManagedObject"
], function (
    ManagedObject
) {
    "use strict";

    return ManagedObject.extend("cdm.services.core.BaseService", {
        /**
         * @returns {sap.ui.model.Model}
         */
        getDataModel: function () {
            return this._oDataModel;
        },

        /**
         * @param {sap.ui.model.Model} oDataModel
         */
        setDataModel: function (oDataModel) {
            this._oDataModel = oDataModel;
        }
    });
});