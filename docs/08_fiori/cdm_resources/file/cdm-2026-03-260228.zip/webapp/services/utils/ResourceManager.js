sap.ui.define([
    "sap/ui/model/json/JSONModel"
], function (JSONModel) {
    "use strict";

    /**
     * 资源管理器 - 处理图片资源路径和模型设置
     */
    return {
        initialize: function (oComponent) {
            this._sModulePath = oComponent.getCdmModulePath();
            this._oResourceModel = new sap.ui.model.json.JSONModel();
            oComponent.setModel(this._oResourceModel, "resource");
        },

        /**
         * 获取完整的图片资源路径
         * @param {string|Object} vImagePath - 图片相对路径或包含src属性的对象
         * @returns {string} 完整路径
         */
        getImageUrl: function (vImagePath) {
            // 如果是对象，提取 src 属性
            var sImagePath = typeof vImagePath === 'object'
                ? vImagePath.src
                : vImagePath;

            if (!sImagePath) {
                console.warn("getImageUrl: 未提供有效的图片路径");
                return "";
            }

            // 确保路径拼接正确
            return sImagePath.startsWith('/')
                ? `${this._sModulePath}${sImagePath}`
                : `${this._sModulePath}/${sImagePath}`;
        },

        /**
         * 获取完整的 JSON 资源路径
         * @param {string} sJsonPath - JSON 文件相对路径
         * @returns {string} 完整路径
         */
        getJsonUrl: function (sJsonPath) {
            if (!sJsonPath) {
                console.warn("getJsonUrl: 未提供有效的 JSON 路径");
                return "";
            }

            // 确保路径拼接正确
            return sJsonPath.startsWith('/')
                ? `${this._sModulePath}${sJsonPath}`
                : `${this._sModulePath}/${sJsonPath}`;
        },

        /**
         * 处理图片资源对象，将相对路径转换为完整路径
         * @param {Object} oImageObj - 图片对象
         * @returns {Object} 处理后的图片对象
         */
        _processImageObject: function (oImageObj) {
            if (oImageObj.src) {
                return {
                    ...oImageObj,
                    src: this.getImageUrl(oImageObj.src)
                };
            }
            return oImageObj;
        },

        /**
         * 确保路径存在，自动创建中间对象
         * @param {string} sPropertyPath - 模型属性路径
         * @private
         */
        _ensurePathExists: function (sPropertyPath) {
            if (!sPropertyPath || sPropertyPath === "/") {
                return;
            }

            // 移除开头的斜杠并分割路径
            var sPath = sPropertyPath.startsWith('/') ? sPropertyPath.substring(1) : sPropertyPath;
            var aParts = sPath.split('/');

            // 如果是根路径直接返回
            if (aParts.length <= 1) {
                return;
            }

            // 构建并确保中间路径存在
            var sCurrentPath = "";
            for (var i = 0; i < aParts.length - 1; i++) {
                sCurrentPath += (i === 0 ? "" : "/") + aParts[i];
                var sFullPath = "/" + sCurrentPath;

                // 检查路径是否存在，如果不存在则创建空对象
                var oCurrent = this._oResourceModel.getProperty(sFullPath);
                if (oCurrent === undefined) {
                    this._oResourceModel.setProperty(sFullPath, {});
                }
            }
        },

        /**
         * 设置模型中的图片
         * @param {string} sPropertyPath - 模型属性路径
         * @param {string|Object} vImage - 图片路径或对象
         */
        setImage: function (sPropertyPath, vImage) {
            if (!sPropertyPath) {
                console.warn("setImage: 未提供属性路径");
                return;
            }

            // 确保路径存在
            this._ensurePathExists(sPropertyPath);

            var oResource;

            if (typeof vImage === 'object') {
                // 处理对象类型
                oResource = this._processImageObject(vImage);
            } else {
                // 处理字符串类型
                oResource = this.getImageUrl(vImage);
            }

            this._oResourceModel.setProperty(sPropertyPath, oResource);
        },

        /**
         * 批量设置模型中的图片
         * @param {Object} oImageMap - 属性路径到图片的映射
         * 示例: { "/S01_02": "images/a.png", "/S01_02/card2": { src: "images/b.png", alt: "图片B" } }
         */
        setImages: function (oImageMap) {
            Object.keys(oImageMap).forEach((sPropertyPath) => {
                this.setImage(sPropertyPath, oImageMap[sPropertyPath]);
            });
        },

        /**
         * 加载 JSON 文件
         * @param {string} sJsonPath - JSON 文件相对路径
         * @param {function} fnCallback - 回调函数，接收加载的数据
         * @param {Object} [oOptions] - 可选参数
         * @param {boolean} [oOptions.async=true] - 是否异步加载
         * @param {function} [oOptions.errorCallback] - 错误回调函数
         */
        loadJson: function (sJsonPath, fnCallback, oOptions) {
            if (!sJsonPath || typeof fnCallback !== 'function') {
                console.warn("loadJson: 参数无效");
                return;
            }

            var sFullPath = this.getJsonUrl(sJsonPath);
            var bAsync = (oOptions && oOptions.async !== undefined) ? oOptions.async : true;
            var fnErrorCallback = (oOptions && oOptions.errorCallback) || function (oError) {
                console.error(`加载 JSON 文件失败: ${sFullPath}`, oError);
            };

            // 创建 JSONModel 加载数据
            var oJsonModel = new JSONModel(sFullPath);

            // 设置异步加载
            oJsonModel.setSizeLimit(1000000); // 设置大小限制，避免大文件问题
            oJsonModel.setDefaultBindingMode("OneWay");

            // 监听请求完成事件
            oJsonModel.attachRequestCompleted(function (oEvent) {
                var oData = oJsonModel.getData();
                fnCallback(oData);
            });

            // 监听请求失败事件
            oJsonModel.attachRequestFailed(function (oEvent) {
                fnErrorCallback(oEvent.getParameters());
            });

            // 加载数据
            oJsonModel.loadData(sFullPath, null, !bAsync);
        },

        /**
         * 批量加载多个 JSON 文件
         * @param {Array} aJsonPaths - JSON 文件路径数组
         * @param {function} fnAllCallback - 所有文件加载完成后的回调函数
         * @param {Object} [oOptions] - 可选参数
         */
        loadJsons: function (aJsonPaths, fnAllCallback, oOptions) {
            if (!Array.isArray(aJsonPaths) || typeof fnAllCallback !== 'function') {
                console.warn("loadJsons: 参数无效");
                return;
            }

            var iTotal = aJsonPaths.length;
            var iLoaded = 0;
            var aResults = new Array(iTotal);

            aJsonPaths.forEach(function (sJsonPath, iIndex) {
                this.loadJson(sJsonPath, function (oData) {
                    aResults[iIndex] = {
                        path: sJsonPath,
                        data: oData,
                        index: iIndex
                    };
                    iLoaded++;

                    // 所有文件加载完成
                    if (iLoaded === iTotal) {
                        fnAllCallback(aResults);
                    }
                }, oOptions);
            }, this);
        }
    };
});