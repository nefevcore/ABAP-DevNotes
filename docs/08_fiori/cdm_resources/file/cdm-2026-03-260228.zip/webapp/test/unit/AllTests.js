sap.ui.define([
	"cdm/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
