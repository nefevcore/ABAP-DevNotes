/* global QUnit */

sap.ui.require(["cdm/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
