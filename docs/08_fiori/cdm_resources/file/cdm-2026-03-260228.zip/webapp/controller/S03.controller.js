sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "cdm/services/ServiceManager",
    "cdm/ui/control/TableUtil",
], (Controller,
    /** @type {cdm.services.ServiceManager} */ ServiceMnager,
    CdmTableUtil
) => {
    "use strict";

    return Controller.extend("cdm.controller.S03", {
        onInit() {
            this.api = ServiceMnager.createMonitorService(this.getOwnerComponent().getModel());
        },

        /**
         * @override
         */
        onAfterRendering: function () {
            this._setup_all_components();
            this._setup_timer();
        },

        /**
         * 测试组件是否能正常处理
         */
        _setup_all_components: function () {
            this._setup_S03_01();
            this._setup_S03_02();
            this._setup_S03_03();
            this._setup_S03_04();
            this._setup_S03_05();
            this._setup_S03_06();
            this._setup_S03_07();
        },

        _setup_timer: function () {
            this.api.getComponentOption("CONFIG").then((data) => {
                setInterval(() => this._update_S03_01(), (data.S03_01 && data.S03_01.interval) ? data.S03_01.interval : 5000);
                setInterval(() => this._update_S03_04(), (data.S03_04 && data.S03_04.interval) ? data.S03_04.interval : 5000);
                // setInterval(() => this._update_S03_07(), (data.S03_07 && data.S03_07.interval) ? data.S03_07.interval : 5000);
            });
        },

        _setup_S03_01: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_01");

            this.api.getComponentOption("S03_01").then((data) => {
                // 获取颜色数组
                const colors = CdmTableUtil.getColors();

                // 准备ECharts数据
                const chartData = data.map((item, index) => {
                    const ratioNumber = parseFloat(item.ratio.replace('%', ''));

                    // 分配颜色类
                    const colorClasses = CdmTableUtil.getColorClasses();
                    item.color = index < 10 ? colorClasses[index % colorClasses.length] : colorClasses[10];
                    item.highlight = ratioNumber > 20;

                    return {
                        name: item.docType,
                        value: item.number,
                        percent: item.ratio,
                        itemStyle: {
                            color: colors[index < 10 ? index % colors.length : 10]
                        }
                    };
                });

                const option = {
                    tooltip: { trigger: 'item', confine: true },
                    series: [{
                        data: chartData,
                        type: 'pie',
                        radius: ['50%', '80%'],
                        avoidLabelOverlap: false,
                        label: {
                            show: false,
                            position: 'inner',
                            formatter: '{d}%',
                            fontSize: 12,
                            fontWeight: 'bold',
                            color: '#fff'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: 16,
                                fontWeight: 'bold'
                            },
                            scale: true,
                            scaleSize: 8
                        }
                    }]
                };

                oModel.setData({
                    aTransitDocs: data,
                    echartOption: option
                });
            });

            this.getView().byId("id_S03_01_TransitDoc_Table").attachRowsUpdated((oEvent) => {
                var aRows = oEvent.getSource().getRows();
                aRows.forEach((oRow) => {
                    var oCtx = oRow.getBindingContext("S03_01");
                    if (oCtx) {
                        var oItem = oCtx.getObject();
                        oRow.getCells().forEach((oCell) => {
                            var sFieldname = oCell.data("fieldname");
                            if (sFieldname === "docType") {
                                // 使用 CdmTableUtil 设置颜色块
                                CdmTableUtil.setColorBlockToCell(oCell, oItem.color);
                            } else if (oCell.data("fieldname") === "ratio") {
                                if (oItem.highlight)
                                    oCell.addStyleClass("highlight");
                                else
                                    oCell.removeStyleClass("highlight");
                            }
                        });
                    }
                });
            });
        },

        _update_S03_01: function () {
            var oTable = this.byId("id_S03_01_TransitDoc_Table");
            var oRowMode = oTable.getRowMode();
            var rowCount = oRowMode.getTotalRowCountOfTable();
            var rowVisCount = oRowMode.getMinRowCount();

            // 获取当前第一个可见行
            var currentFirstRow = oTable.getFirstVisibleRow();

            // 计算下一个位置
            var next = currentFirstRow + rowVisCount;

            // 如果超出总行数，回到第一行
            if (next >= rowCount)
                next = 0;

            oTable.setFirstVisibleRow(next);
        },

        _setup_S03_02: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_02");

            this.api.getComponentOption("S03_02").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S03_03: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_03");

            var oResourceManager = this.getOwnerComponent().getResourceManager();
            oResourceManager.setImage("/S03_03/background", "/images/order-status-container-bg.png");
            oResourceManager.setImage("/S03_03/newPooling", "/images/icon-newPooling.png");
            oResourceManager.setImage("/S03_03/dispatched", "/images/icon-dispatched.png");
            oResourceManager.setImage("/S03_03/pendingDispatchpng", "/images/icon-pendingDispatchpng.png");
            oResourceManager.setImage("/S03_03/onHold", "/images/icon-onHold.png");

            this.api.getComponentOption("S03_03").then((data) => {
                oModel.setProperty("/OrderStatus", data.OrderStatus);
            });
        },

        _setup_S03_04: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_04");

            this.api.getComponentOption("S03_04").then((data) => {
                oModel.setData({ aWorkflowTimeouts: data });
            });

            this.getView().byId("id_S03_04_WorkflowTimeout_Table").attachRowsUpdated((oEvent) => {
                var aRows = oEvent.getSource().getRows();
                aRows.forEach((oRow) => {
                    var oCtx = oRow.getBindingContext("S03_04");
                    if (oCtx) {
                        var oItem = oCtx.getObject();
                        if (oItem.status === "紧急")
                            oRow.addStyleClass("row-highlight");
                        else
                            oRow.removeStyleClass("row-highlight");
                    }
                });
            });
        },

        _update_S03_04: function () {
            var oTable = this.byId("id_S03_04_WorkflowTimeout_Table");
            var oRowMode = oTable.getRowMode();
            var rowCount = oRowMode.getTotalRowCountOfTable();
            var rowVisCount = oRowMode.getMinRowCount();

            // 获取当前第一个可见行
            var currentFirstRow = oTable.getFirstVisibleRow();

            // 计算下一个位置
            var next = currentFirstRow + rowVisCount;

            // 如果超出总行数，回到第一行
            if (next >= rowCount)
                next = 0;

            oTable.setFirstVisibleRow(next);
        },

        _setup_S03_05: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            var oData = {};
            this.getView().setModel(oModel, "S03_05");

            this.api.getComponentOption("S03_05A").then((data) => {
                oData.fpy = {
                    maxValue: data.OrderStatus.maxValue,
                    minValue: data.OrderStatus.minValue,
                    avgValue: data.OrderStatus.avgValue
                };
                oModel.setData(oData);
            });
            this.api.getComponentOption("S03_05B").then((data) => {
                oData.aRejectionStats = data;
                oModel.setData(oData);
            });
        },

        _setup_S03_06: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_06");

            this.api.getComponentOption("S03_06").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S03_07: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S03_07");

            this.api.getComponentOption("S03_07").then((data) => {
                data.dataZoom = {
                    type: "slider",
                    show: false,
                    start: 0,
                    end: 100,
                    filterMode: 'none'
                };

                oModel.setData({
                    echartOption: data,
                    dataZoom: data.dataZoom
                });
            });
        },

        _update_S03_07: function () {
            // var oModel = this.getView().getModel("S03_07");
            // var oData = oModel.getData();
            // if (!oModel || !oData || !oData.dataZoom)
            //     return;

            // var step = 10;
            // var start = oData.dataZoom.start + step * 2;
            // var end = start + step;
            // if (end > 100 + step + 1) {
            //     start = 0;
            //     end = start + step;
            // }

            // oData.dataZoom.start = start;
            // oData.dataZoom.end = end;

            // var updateOption = {
            //     animation: true, // 开启动画
            //     animationDuration: 5000, // 动画时长
            //     animationEasing: 'linear', // 缓动函数
            //     animationDurationUpdate: 5000, // 数据更新动画时长
            //     animationEasingUpdate: 'linear', // 更新缓动函数
            //     dataZoom: oData.dataZoom
            // };

            // console.log(updateOption);

            // this.byId("id_S03_07_EchartContainer").getEchart().setOption(updateOption);

            // oModel.setData(oData);
        }
    });
});