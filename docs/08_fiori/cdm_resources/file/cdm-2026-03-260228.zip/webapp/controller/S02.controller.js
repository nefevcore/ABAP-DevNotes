sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "cdm/services/ServiceManager",
    "cdm/ui/control/TableUtil",
], (Controller,
    /** @type {cdm.services.ServiceManager} */ ServiceMnager,
    CdmTableUtil
) => {
    "use strict";

    const StatPeriod = {
        DAY: "day",
        MONTH: "month",
        YEAR: "year"
    };

    return Controller.extend("cdm.controller.S02", {
        onInit() {
            /** @type {cdm.services.api.MonitorService} */
            this.api = ServiceMnager.createMonitorService(this.getOwnerComponent().getModel());
        },

        /**
         * @override
         */
        onAfterRendering: function () {
            this._setup_all_components();
            this._setup_timer();
        },

        /**
         * 测试组件是否能正常处理
         */
        _setup_all_components: function () {
            this._setup_S02_01();
            this._setup_S02_02();
            this._setup_S02_03();
            this._setup_S02_04();
            this._setup_S02_05();
            this._setup_S02_06();
            this._setup_S02_07();
            this._setup_S02_08();
        },

        _setup_timer: function () {
            this.api.getComponentOption("CONFIG").then((data) => {
                setInterval(() => this._update_S02_01(), (data.S02_01 && data.S02_01.interval) ? data.S02_01.interval : 10000);
                setInterval(() => this._update_S02_01A(), (data.S02_01A && data.S02_01A.interval) ? data.S02_01.interval : 10000);
                setInterval(() => this._update_S02_01B(), (data.S02_01B && data.S02_01B.interval) ? data.S02_01.interval : 300000);
                setInterval(() => this._update_S02_01C(), (data.S02_01C && data.S02_01C.interval) ? data.S02_01.interval : 3650000);
                setInterval(() => this._update_S02_08(), (data.S02_08 && data.S02_08.interval) ? data.S02_08.interval : 5000);
            });
        },

        _setup_S02_01: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_01");

            this._update_S02_01A();
            this._update_S02_01B();
            this._update_S02_01C();

            const fnRowsUpdated = function (oEvent) {
                var aRows = oEvent.getSource().getRows();
                aRows.forEach((oRow) => {
                    var oCtx = oRow.getBindingContext("S02_01");
                    if (oCtx) {
                        var oItem = oCtx.getObject();
                        oRow.getCells().forEach((oCell) => {
                            var sFieldname = oCell.data("fieldname");
                            if (sFieldname === "servicecatalogl1text") {
                                // 使用 CdmTableUtil 设置颜色块
                                CdmTableUtil.setColorBlockToCell(oCell, oCell.data("color"));
                            }
                        });
                    }
                });
            };

            this.getView().byId("id_S02_01_StatDocByDay_Table").attachRowsUpdated(fnRowsUpdated);
            this.getView().byId("id_S02_01_StatDocByMonth_Table").attachRowsUpdated(fnRowsUpdated);
            this.getView().byId("id_S02_01_StatDocByYear_Table").attachRowsUpdated(fnRowsUpdated);

            this.getView().byId("id_S02_01_TabBar").attachSelect((/** @type {sap.ui.base.Event} */ oEvent) => {
                console.log("attachSelect", oEvent.getParameter("selectedKey"));
                this._S02_01_next_stat(oEvent.getParameter("selectedKey"));
            });
        },

        _update_S02_01: function () {
            /** @type {sap.ui.model.json.JSONModel} */
            var oModel = this.getView().getModel("S02_01");

            var nextStat = oModel.getProperty("/nextStat");
            if (nextStat) {
                this._S02_01_next_stat(nextStat);
            }
        },

        _S02_01_next_stat: function (nextStat) {
            /** @type {sap.ui.model.json.JSONModel} */
            var oModel = this.getView().getModel("S02_01");
            var echartOption;

            if (nextStat === StatPeriod.DAY) {
                oModel.setProperty("/selectedKey", StatPeriod.DAY);
                oModel.setProperty("/nextStat", StatPeriod.MONTH);
                echartOption = oModel.getProperty("/echartOptionByDay");
            } else if (nextStat === StatPeriod.MONTH) {
                oModel.setProperty("/selectedKey", StatPeriod.MONTH);
                oModel.setProperty("/nextStat", StatPeriod.YEAR);
                echartOption = oModel.getProperty("/echartOptionByMonth");
            } else if (nextStat === StatPeriod.YEAR) {
                oModel.setProperty("/selectedKey", StatPeriod.YEAR);
                oModel.setProperty("/nextStat", StatPeriod.DAY);
                echartOption = oModel.getProperty("/echartOptionByYear");
            }

            oModel.setProperty("/echartOption", echartOption);
        },

        _update_S02_01A: function () {
            /** @type {sap.ui.model.json.JSONModel} */
            var oModel = this.getView().getModel("S02_01");
            this.api.getComponentOption("S02_01A").then((data) => {
                oModel.setProperty("/aStatDocByDay", this._colorize_S02_01(data));
                oModel.setProperty("/echartOptionByDay", this._conv_S02_01_echartOption(data));
                // 初次进入页面
                var nextStat = oModel.getProperty("/nextStat");
                if (!nextStat) {
                    oModel.setProperty("/echartOption", this._conv_S02_01_echartOption(data));
                    this._S02_01_next_stat(StatPeriod.DAY);
                }
            });
        },

        _update_S02_01B: function () {
            /** @type {sap.ui.model.json.JSONModel} */
            var oModel = this.getView().getModel("S02_01");
            this.api.getComponentOption("S02_01B").then((data) => {
                oModel.setProperty("/aStatDocByMonth", this._colorize_S02_01(data));
                oModel.setProperty("/echartOptionByMonth", this._conv_S02_01_echartOption(data));
            });
        },

        _update_S02_01C: function () {
            /** @type {sap.ui.model.json.JSONModel} */
            var oModel = this.getView().getModel("S02_01");
            this.api.getComponentOption("S02_01C").then((data) => {
                oModel.setProperty("/aStatDocByYear", this._colorize_S02_01(data));
                oModel.setProperty("/echartOptionByYear", this._conv_S02_01_echartOption(data));
            });
        },

        _colorize_S02_01: function (data) {
            const colorClasses = CdmTableUtil.getColorClasses();
            data.forEach((item, index) => {
                item.color = index < 10 ? colorClasses[index % colorClasses.length] : colorClasses[10];
            });
            return data;
        },

        _conv_S02_01_echartOption: function (data) {
            const colors = CdmTableUtil.getColors();

            // 构建数据系列
            const echartData = data.map((item, index) => {
                const colorIndex = index % colors.length;
                return {
                    name: item.servicecatalogl1text,
                    value: item.count,
                    itemStyle: {
                        color: colors[colorIndex]
                    }
                };
            });

            // 计算最大值
            const max = Math.max(...data.map(item => item.count)) * 1.35;

            // ECharts配置
            const option = {
                // polar配置
                polar: {
                    radius: [30, '80%'],
                    axisLine: {
                        show: false
                    }
                },

                // 角度轴配置
                angleAxis: {
                    max: max,
                    startAngle: 90,
                    rotate: 0,
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show: false
                    },
                    splitLine: {
                        show: false
                    },
                    inverse: true
                },

                // 径向轴配置
                radiusAxis: {
                    show: false,
                    type: 'category',
                    data: echartData.map(item => item.name || '--')
                },

                // 提示框配置
                tooltip: {},

                // 系列配置
                series: [
                    {
                        // 彩色数据系列
                        type: 'bar',
                        data: echartData,
                        coordinateSystem: 'polar',
                        barWidth: "60%",
                        z: 1,
                        label: {
                            show: true,
                            position: 'start',
                            distance: 0,
                            align: 'left',
                            verticalAlign: 'middle',
                            fontSize: 12,
                            rotate: 0,
                            layout: 'horizontal',
                            offset: [5, 0],
                            formatter: '{c}',  // 只显示数值
                            color: "white"
                        }
                    }
                ]
            };

            return option;
        },

        _setup_S02_02: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_02");

            var oResourceManager = this.getOwnerComponent().getResourceManager();
            oResourceManager.setImage("/S02_02/background", "/images/annual-document-container-bg.png");

            this.api.getComponentOption("S02_02").then((data) => {
                data.forEach(item => {
                    if (item.ksname === '核算室') {
                        oModel.setProperty("/card1", { value: item.count });
                    }
                    if (item.ksname === '工程资产室') {
                        oModel.setProperty("/card2", { value: item.count });
                    }
                    if (item.ksname === '结算室') {
                        oModel.setProperty("/card3", { value: item.count });
                    }
                    if (item.ksname === '报表室') {
                        oModel.setProperty("/card4", { value: item.count });
                    }
                });
            });
        },

        _setup_S02_03: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_03");

            this.api.getComponentOption("S02_03").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S02_04: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_04");

            this.api.getComponentOption("S02_04").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S02_05: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_05");

            var oResourceManager = this.getOwnerComponent().getResourceManager();
            oResourceManager.setImage("/S02_05/annualReport", "/images/annualReport.png");
            oResourceManager.setImage("/S02_05/quickReport", "/images/quickReport.png");
            oResourceManager.setImage("/S02_05/monthlyReport", "/images/monthlyReport.png");

            // this.api.getComponentOption("S02_05").then((data) => {
            // });
        },

        _setup_S02_06: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_06");

            var oResourceManager = this.getOwnerComponent().getResourceManager();
            oResourceManager.setImage("/S02_06/AssetCardIncome", "/images/AssetCardIncome.png");

            this.api.getComponentOption("S02_06").then((data) => {
                var extractedData = this._extractFundsChartData(data);
                data.graphic = null; // 通过其他组件特殊处理，不在Echart中展示

                oModel.setProperty("/echartOption", data);
                oModel.setProperty("/currentMonth", extractedData);
            });
        },

        _setup_S02_07: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_07");

            var oResourceManager = this.getOwnerComponent().getResourceManager();
            oResourceManager.setImage("/S02_07/AssetCardExpense", "/images/AssetCardExpense.png");

            this.api.getComponentOption("S02_07").then((data) => {
                var extractedData = this._extractFundsChartData(data);
                data.graphic = null; // 通过其他组件特殊处理，不在Echart中展示

                oModel.setProperty("/echartOption", data);
                oModel.setProperty("/currentMonth", extractedData);
            });
        },

        _extractFundsChartData: function (config) {
            if (!config || !config.series || !config.series[0]) {
                return {
                    currentAmount: {
                        value: 0,
                        unit: "亿元",
                        fullText: "0亿元"
                    },
                    annualRatio: {
                        value: 0,
                        unit: "%",
                        fullText: "0%"
                    }
                };
            }

            // 1. 分析本期款项
            const barSeries = config.series[0];
            const currentMonthIndex = this._getCurrentMonthIndex(); // 获取当前月份索引
            const currentAmountValue = barSeries.data[currentMonthIndex] || 0;

            // 从配置中提取单位（默认为"亿元"）
            const unit = config.yAxis && config.yAxis[0] && config.yAxis[0].name
                ? config.yAxis[0].name
                : "亿元";

            // 2. 分析全年占比
            const totalAmount = barSeries.data.reduce((sum, value) => sum + (value || 0), 0);
            const annualRatioValue = totalAmount > 0
                ? ((currentAmountValue / totalAmount) * 100).toFixed(2)
                : 0;

            // 3. 拆分数字和单位
            const currentAmount = {
                value: currentAmountValue,
                unit: unit,
                fullText: `${this._formatNumber(currentAmountValue)}${unit}`
            };

            const annualRatio = {
                value: parseFloat(annualRatioValue),
                unit: "%",
                fullText: `${annualRatioValue}%`
            };

            return {
                currentAmount: currentAmount,
                annualRatio: annualRatio,
                totalAmount: totalAmount,
                monthData: barSeries.data
            };
        },

        // 辅助函数：获取当前月份索引（0-11对应1-12月）
        _getCurrentMonthIndex: function () {
            const now = new Date();
            return now.getMonth(); // 0-11
        },

        // 辅助函数：格式化数字（添加千分位分隔符）
        _formatNumber: function (num) {
            if (typeof num !== 'number') return num;

            // 如果是整数，直接添加千分位
            if (Number.isInteger(num)) {
                return num.toLocaleString('zh-CN');
            }

            // 如果是小数，保留2位小数并添加千分位
            return num.toLocaleString('zh-CN', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        },

        _setup_S02_08: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S02_08");

            this.api.getComponentOption("S02_08").then((data) => {
                oModel.setData({ aBankAccounts: data });
            });
        },

        _update_S02_08: function () {
            var oTable = this.byId("id_S02_08_BankAccount_Table");
            var oRowMode = oTable.getRowMode();
            var rowCount = oRowMode.getTotalRowCountOfTable();
            var rowVisCount = oRowMode.getMinRowCount();

            // 获取当前第一个可见行
            var currentFirstRow = oTable.getFirstVisibleRow();

            // 计算下一个位置
            var next = currentFirstRow + rowVisCount;

            // 如果超出总行数，回到第一行
            if (next >= rowCount)
                next = 0;

            oTable.setFirstVisibleRow(next);
        },
    });
});