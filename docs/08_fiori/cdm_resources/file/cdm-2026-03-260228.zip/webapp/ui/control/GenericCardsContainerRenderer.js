sap.ui.define([
], function () {
    "use strict";

    /**
     * GenericCardsContainer renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        var id = oControl.getId();
        var layoutType = oControl.getProperty("layoutType");

        // 开始渲染容器
        rm.openStart("div", id)
            .class("cdm-cards-container")
            .class("cdm-cards-container--layout-" + layoutType);

        // 根据布局类型设置样式
        if (layoutType === "flex") {
            rm.style("display", "flex")
                .style("flex-direction", oControl.getProperty("flexDirection"))
                .style("flex-wrap", oControl.getProperty("flexWrap"))
                .style("justify-content", oControl.getProperty("justifyContent"))
                .style("align-items", oControl.getProperty("alignItems"))
                .style("align-content", oControl.getProperty("alignContent"))
                .style("gap", oControl.getProperty("flexGap"));
        } else if (layoutType === "grid") {
            rm.style("display", "grid")
                .style("grid-template-columns", oControl.getProperty("gridTemplateColumns"))
                .style("grid-template-rows", oControl.getProperty("gridTemplateRows"))
                .style("grid-auto-flow", oControl.getProperty("gridAutoFlow"))
                .style("gap", oControl.getProperty("gridGap"))
                .style("justify-items", oControl.getProperty("gridJustifyItems"))
                .style("align-items", oControl.getProperty("gridAlignItems"));
        }

        rm.openEnd();


        // 渲染背景设置 - 渲染所有背景
        var aBackgrounds = oControl.getAggregation("backgrounds") || [];
        if (aBackgrounds.length > 0) {
            rm.openStart("div", id + "-backgrounds")
                .class("cdm-cards-container-backgrounds")
                .openEnd();

            // 按 z-index 排序渲染背景
            aBackgrounds.sort(function (a, b) {
                return (a.getZIndex() || 0) - (b.getZIndex() || 0);
            });

            aBackgrounds.forEach(function (oBackground) {
                rm.renderControl(oBackground);
            });

            rm.close("div");
        }

        // 渲染所有卡片
        var aCards = oControl.getAggregation("cards") || [];
        for (let index = 0; index < aCards.length; index++) {
            rm.renderControl(aCards[index]);
        }

        rm.close("div");
    };

    return Renderer;
});