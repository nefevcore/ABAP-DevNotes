sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TabBarItemRenderer",
    "sap/ui/core/Icon"
], function (
    Control, TabBarItemRenderer, Icon
) {
    "use strict";

    return Control.extend("cdm.ui.control.TabBarItem", {
        metadata: {
            properties: {
                text: { type: "string", defaultValue: "" },
                key: { type: "string", defaultValue: "" },
                icon: { type: "string", defaultValue: "" },
            },
            aggregations: {
                panel: { type: "sap.ui.core.Control", multiple: true, defaultValue: null }
            },
            renderer: TabBarItemRenderer
        },

        init: function () {
            // 如果有图标，创建Icon控件
            var sIcon = this.getIcon();
            if (sIcon) {
                this.setAggregation("_icon", new Icon({
                    src: sIcon
                }));
            }
        },

        setIcon: function (sIcon) {
            this.setProperty("icon", sIcon, true);

            // 更新图标控件
            var oIcon = this.getAggregation("_icon");
            if (oIcon) {
                oIcon.setSrc(sIcon);
            } else if (sIcon) {
                this.setAggregation("_icon", new Icon({
                    src: sIcon
                }));
            }

            return this;
        },

        getTabDomRef: function () {
            return document.getElementById(this.getId() + "-tab");
        }
    });
});