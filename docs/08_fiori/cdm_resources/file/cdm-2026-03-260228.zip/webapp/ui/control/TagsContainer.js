sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TagRenderer",
], function (
    Control, TagRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.TagsContainer", {

        metadata: {
            aggregations: {
                tags: { type: "cdm.ui.control.Tag", multiple: true, defaultValue: null },
            },
            renderer: TagRenderer
        }
    });
});