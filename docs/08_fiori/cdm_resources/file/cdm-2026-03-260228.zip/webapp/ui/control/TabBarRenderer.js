/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        var id = oControl.getId();
        var aItems = oControl.getItems();

        // 渲染TabBar容器
        rm.openStart("div", id)
            .class("cdm-tab-bar")
            .openEnd(); {

            // 渲染标签头
            rm.openStart("div", id + "-header")
                .class("cdm-tab-header")
                .openEnd(); {
                // 渲染所有标签项
                aItems.forEach(function (oItem) {
                    Renderer._renderTabItem(rm, oItem);
                });
            } rm.close("div"); // 关闭标签头

            // 渲染标签内容区域
            rm.openStart("div", id + "-body")
                .class("cdm-tab-body")
                .openEnd(); {
                // 渲染所有面板
                aItems.forEach(function (oItem) {
                    Renderer._renderTabPanel(rm, oItem);
                });
            } rm.close("div"); // 关闭标签内容区域

        } rm.close("div"); // 关闭TabBar容器
    };

    Renderer._renderTabItem = function (rm, oItem) {
        var id = oItem.getId();
        var sKey = oItem.getKey();
        var sText = oItem.getText();
        var sIcon = oItem.getIcon();
        var oParent = oItem.getParent();
        var sSelectedKey = oParent ? oParent.getSelectedKey() : "";
        var bActive = sKey === sSelectedKey;

        rm.openStart("button", id + "-tab")
            .class("cdm-tab-item")
            .class("cdm-tab-sharp") // 固定平行四边形
            .class(bActive ? "cdm-active" : "")
            .attr("data-key", sKey)
            .openEnd(); {

            // 渲染标签内容
            rm.openStart("div")
                .class("cdm-tab-content")
                .openEnd();

            // 渲染图标
            if (sIcon) {
                var oIcon = oItem.getAggregation("_icon");
                if (oIcon) {
                    rm.renderControl(oIcon);
                }
            }

            // 渲染文本
            if (sText) {
                rm.text(sText);
            }

            rm.close("div");

        } rm.close("button");
    };

    Renderer._renderTabPanel = function (rm, oItem) {
        var id = oItem.getId();
        var aPanelItems = oItem.getPanel();

        var sKey = oItem.getKey();
        var oParent = oItem.getParent();
        var sSelectedKey = oParent ? oParent.getSelectedKey() : "";
        var bActive = sKey === sSelectedKey;

        rm.openStart("div", id)
            .class("cdm-tab-pane")
            .class(bActive ? "cdm-active" : "")
            .attr("data-key", sKey)
            .openEnd(); {

            aPanelItems.forEach(function (oPanelItem) {
                rm.renderControl(oPanelItem);
            });

        } rm.close("div");
    };

    return Renderer;
});