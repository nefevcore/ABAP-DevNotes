/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        var id = oControl.getId();

        // 渲染时间轴容器
        rm.openStart("div", id)
            .class("cdm-tag")
            .openEnd(); {

            var tagCode = oControl.getTagCode();
            if (tagCode) {
                rm.openStart("span", id + "-code")
                    .class("cdm-tag-code")
                    .openEnd(); {
                    rm.text(oControl.getTagCode());
                } rm.close("span");
            }

            rm.openStart("span", id + "-name")
                .class("cdm-tag-name")
                .openEnd(); {
                rm.text(oControl.getTagName());
            } rm.close("span");

        } rm.close("div");
    };

    return Renderer;
});
