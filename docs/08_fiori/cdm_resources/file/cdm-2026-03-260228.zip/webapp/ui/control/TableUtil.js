sap.ui.define([
], function (
) {
    "use strict";

    var CdmTableUtil = {
        /**
         * 为单个单元格设置颜色块
         * @param {sap.ui.core.Control} oCell - 单元格控件
         * @param {string} sColorClass - 颜色类名
         */
        setColorBlockToCell: function (oCell, sColorClass) {
            if (!oCell) return;

            // 移除所有可能存在的颜色类
            CdmTableUtil._removeAllColorClasses(oCell);

            // 设置颜色方块
            oCell.addStyleClass("has-color-block");

            if (sColorClass) {
                oCell.addStyleClass(sColorClass);
            }
        },

        /**
         * 获取ECharts颜色数组
         * @returns {Array<string>} 颜色值数组
         */
        getColors: function () {
            // 从CSS样式表中获取颜色值
            const getColorFromCSS = (colorName) => {
                const computedStyle = getComputedStyle(document.documentElement);
                return computedStyle.getPropertyValue(`--cdm-echart-${colorName}`).trim();
            };
            // 颜色方案 - 从CSS变量获取
            const colorClasses = CdmTableUtil.getColorClasses();
            const colors = colorClasses.map(cls => getColorFromCSS(cls));
            return colors;
        },

        /**
         * 获取ECharts颜色类名数组
         * @returns {Array<string>} 颜色类名数组
         */
        getColorClasses: function () {
            return [
                'color0', 'color1', 'color2', 'color3', 'color4',
                'color5', 'color6', 'color7', 'color8', 'color9', 'color-other'
            ];
        },

        /**
         * 私有方法：移除单元格的所有颜色类
         * @private
         */
        _removeAllColorClasses: function (oCell) {
            // 移除通用颜色类
            for (var i = 0; i <= 9; i++) {
                oCell.removeStyleClass("color" + i);
            }
            oCell.removeStyleClass("color-other");

            // 移除颜色块基础类
            oCell.removeStyleClass("has-color-block");

            // 移除可能通过data-color属性设置的其他颜色类
            var sExistingColor = oCell.data("color");
            if (sExistingColor) {
                oCell.removeStyleClass(sExistingColor);
            }
        }
    };

    return CdmTableUtil;
});