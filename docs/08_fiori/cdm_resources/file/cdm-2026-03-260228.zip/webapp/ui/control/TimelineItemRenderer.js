/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        // var index = oTimelineItem.getParent().indexOfAggregation("items", oTimelineItem);
        // var id = oTimelineItem.getParent().getId() + "-item-" + index;
        var id = oControl.getId();

        rm.openStart("li", id)
            .class("cdm-timeline-item")
            .openEnd(); {

            rm.openStart("input", id + "-checkbox")
                .class("cdm-timeline-checkbox")
                .attr("name", "timeline-group")
                .attr("type", "checkbox"); {
                if (oControl.getChecked()) {
                    rm.attr("checked", true);
                }
                rm.openEnd();
            } rm.close("input");

            rm.openStart("div", id + "-item-wrapper")
                .class("cdm-timeline-item-wrapper")
                .openEnd(); {

                // 左侧
                rm.openStart("div", id + "-item-left")
                    .class("cdm-timeline-item-left")
                    .openEnd(); {
                    // 时间
                    rm.openStart("div", id + "-item-date")
                        .class("cdm-timeline-item-date")
                        .openEnd(); {
                        rm.text(oControl.getDateTime());
                    } rm.close("div");
                } rm.close("div");

                // 右侧
                rm.openStart("div", id + "-item-right")
                    .class("cdm-timeline-item-right")
                    .openEnd(); {
                    // 图标
                    rm.openStart("div", id + "-item-icon")
                        .class("cdm-timeline-item-icon")
                        .openEnd(); {
                    } rm.close("div");
                    // 标题
                    rm.openStart("label", id + "-item-title")
                        .class("cdm-timeline-item-title")
                        .attr("for", id + "-checkbox")
                        .openEnd(); {
                        rm.text(oControl.getTitle());
                    } rm.close("label");
                    // 图标
                    rm.openStart("div", id + "-item-content")
                        .class("cdm-timeline-item-content")
                        .openEnd(); {
                        rm.text(oControl.getText());
                    } rm.close("div");
                } rm.close("div");

            } rm.close("div"); // 关闭 impcContent
        } rm.close("li"); // 关闭 impcWork
    };

    return Renderer;
});
