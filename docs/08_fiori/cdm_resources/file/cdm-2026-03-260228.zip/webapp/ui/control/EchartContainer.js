sap.ui.define([
	"sap/ui/core/Control",
	"cdm/libs/echarts/echarts-min",
	"cdm/ui/control/EchartContainerRenderer",
], function (
	Control,
	__echarts,
	EchartContainerRenderer
) {
	"use strict";

	// Echart主题编辑器
	// https://echarts.apache.org/zh/theme-builder.html
	const echartTheme = 'theme-cdm';

	return Control.extend("cdm.ui.control.EchartContainer", {
		metadata: {
			properties: {
				option: { type: "string", defaultValue: "" },
			},
			renderer: EchartContainerRenderer
		},

		/**
		 * @override
		 * @returns {void|undefined}
		 */
		init: function () {
			this._echart = null;
			// 绑定窗口大小调整事件
			window.addEventListener("resize", () => { this._handleWindowResize(); });

			// // 监听CSS变量变化，动态更新主题（可选）
			// const observer = new MutationObserver(() => {
			// 	if (echarts) {
			// 		if (echarts.getTheme && echarts.getTheme(echartTheme)) {
			// 			const rawThemeData = oThemeModel.getData();
			// 			const processedThemeData = processThemeVariables(rawThemeData);
			// 			echarts.registerTheme(echartTheme, processedThemeData);
			// 		}
			// 	}
			// });

			// // 观察根元素的属性变化（包括style）
			// observer.observe(document.documentElement, {
			// 	attributes: true,
			// 	attributeFilter: ['style']
			// });
		},

		/**
		 * @override
		 * @param {jQuery.Event} oEvent <p>onAfterRendering event object</p>
		 * @returns {void|undefined}
		 */
		onAfterRendering: function (oEvent) {
			if (!this._echart) {
				var uri = `${jQuery.sap.getModulePath("cdm")}/ui/control/echart-cdm-theme.json`;
				var oThemeModel = new sap.ui.model.json.JSONModel(uri);
				oThemeModel.attachRequestCompleted(() => {
					const rawThemeData = oThemeModel.getData();
					const processedThemeData = this._processThemeVariables(rawThemeData);
					echarts.registerTheme(echartTheme, processedThemeData);
					this._echart = echarts.init(document.getElementById(this.getId() + "-echart"), echartTheme);
					// 由于异步，设置可能在初始化之前，因此这里再加一段设置的代码
					if (this._option) {
						this._echart.setOption(this._option);
					}
				});
			}
		},

		/**
		 * 替换主题中的CSS变量为实际值
		 * @param {Object} themeData - 原始主题数据
		 * @returns {Object} 处理后的主题数据
		 */
		_processThemeVariables: function (themeData) {
			// 获取根元素的CSS变量值
			const rootStyles = getComputedStyle(document.documentElement);

			// 递归处理对象中的所有字符串值
			function replaceVariables(obj) {
				if (typeof obj === 'string') {
					// 匹配 var(--variable-name, defaultValue) 格式
					return obj.replace(/var\(\s*--([^,\s)]+)(?:\s*,\s*([^)]+))?\s*\)/g, (match, varName, defaultValue) => {
						// 获取CSS变量值
						const value = rootStyles.getPropertyValue(`--${varName}`).trim();
						return value || defaultValue || match;
					});
				} else if (Array.isArray(obj)) {
					return obj.map(item => replaceVariables(item));
				} else if (obj && typeof obj === 'object') {
					const result = {};
					for (const key in obj) {
						if (obj.hasOwnProperty(key)) {
							result[key] = replaceVariables(obj[key]);
						}
					}
					return result;
				}
				return obj;
			}

			return replaceVariables(themeData);
		},

		/**
		 * 设置ECharts配置选项
		 * @param {Object} option - ECharts配置对象
		 */
		setOption: function (option) {
			// this.setProperty("option", JSON.stringify(option));
			// 浪费资源，直接记录成内部参数即可
			this._option = option;

			if (this._echart && option) {
				this._echart.setOption(option);
			}
		},

		/**
		 * 获取ECharts配置选项
		 */
		getOption: function () {
			// var option = this.getProperty("option") || "";
			// return JSON.parse(option);
			return this._option;
		},

		/**
		 * 处理窗口大小调整事件
		 * @private
		 */
		_handleWindowResize: function () {
			if (this._echart) {
				this._echart.resize();
			}
		},

		getEchart() {
			return this._echart;
		},

		/**
		 * 销毁控件时的清理工作
		 * @override
		 */
		exit: function () {
			// 移除事件监听
			window.removeEventListener("resize", this._handleWindowResize);

			// 销毁echarts实例
			if (this._echart) {
				this._echart.dispose();
				this._echart = null;
			}
		}
	});
});