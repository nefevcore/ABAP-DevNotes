/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

sap.ui.define([
], function () {
    "use strict";

    var Renderer = {
        apiVersion: 2
    };

    Renderer.render = function (rm, oControl) {
        var id = oControl.getId();

        rm.openStart("div", id)
            .style("width", oControl.getCardWidth())
            .style("height", oControl.getCardHeight())

            .style("--card-color", oControl.getCardColor())
            .style("--title-size", oControl.getTitleSize())
            .style("--title-color", oControl.getTitleColor())
            .style("--text-size", oControl.getTextSize())
            .style("--text-color", oControl.getTextColor())
            .style("--value-size", oControl.getValueSize())
            .style("--value-color", oControl.getValueColor())
            .style("--unit-size", oControl.getUnitSize())
            .style("--unit-color", oControl.getUnitColor())

            .class("cdm-card")
            .class("cdm-card--layout-" + oControl.getLayoutDirection())
            .class("cdm-card--backgroud-" + oControl.getBackgroundStyle())
            .class("cdm-card--border-" + oControl.getBorderStyle())
            .class(!!oControl.getSelected() ? "cdm-card--selected" : "")
            .openEnd(); {

            // 图片区域
            this._renderImageArea(rm, oControl);

            // 内容区域
            this._renderContentArea(rm, oControl);

        } rm.close("div");
    };

    Renderer._renderImageArea = function (rm, oControl) {
        rm.openStart("div")
            .style("--image-size", oControl.getImageSize())
            .class("cdm-card-img-area")
            .class(!!oControl.getImageSrc() ? "" : "cdm-card-img-area--hide")
            .openEnd(); {

            if (oControl.getImageSrc()) {
                rm.openStart("img")
                    .class("cdm-card-img")
                    .attr("src", oControl.getImageSrc())
                    .attr("alt", oControl.getImageAlt() || "图标")
                    .attr("loading", "eager")
                    .openEnd()
                    .close("img");
            } else {
                rm.openStart("div")
                    .class("cdm-card-img-placeholder")
                    .openEnd(); {
                    // rm.text("📊");
                } rm.close("div");
            }

        } rm.close("div");
    };

    Renderer._renderContentArea = function (rm, oControl) {
        rm.openStart("div")
            .class("cdm-card-content")
            .class("cdm-card-content--layout-" + oControl.getContentLayout())
            .class("cdm-card-content--align-" + oControl.getContentAlignment())
            .openEnd(); {

            // 标题
            if (oControl.getTitle()) {
                rm.openStart("div")
                    .class("cdm-card-title")
                    .openEnd(); {
                    rm.text(oControl.getTitle());
                } rm.close("div");
            }

            // 副标题
            if (oControl.getSubtitle()) {
                rm.openStart("div")
                    .class("cdm-card-subtitle")
                    .openEnd(); {
                    rm.text(oControl.getSubtitle());
                } rm.close("div");
            }

            // 数值区域
            this._renderValuesArea(rm, oControl);

            // 描述
            if (oControl.getDescription()) {
                rm.openStart("div")
                    .class("cdm-card-description")
                    .openEnd(); {
                    rm.text(oControl.getDescription());
                } rm.close("div");
            }

        } rm.close("div");
    };

    Renderer._renderValuesArea = function (rm, oControl) {
        rm.openStart("div")
            .class("cdm-card-values")
            .class("cdm-card-values--layout-" + oControl.getValuesLayout())
            .openEnd(); {

            // 主数值
            if (oControl.getPrimaryValue()) {
                rm.openStart("div")
                    .class("cdm-card-value-primary")
                    .openEnd(); {
                    if (oControl.getPrimaryLabel()) {
                        rm.openStart("span")
                            .class("cdm-card-label-primary")
                            .openEnd(); {
                            rm.text(oControl.getPrimaryLabel() + " ");
                        } rm.close("span");
                    }
                    rm.text(oControl.getPrimaryValue());
                    if (oControl.getPrimaryUnit()) {
                        rm.openStart("span")
                            .class("cdm-card-unit-primary")
                            .openEnd(); {
                            rm.text(" " + oControl.getPrimaryUnit());
                        } rm.close("span");
                    }
                } rm.close("div");
            }

            // 第二数值
            if (oControl.getSecondaryValue()) {
                rm.openStart("div")
                    .class("cdm-card-value-secondary")
                    .openEnd(); {
                    if (oControl.getSecondaryLabel()) {
                        rm.openStart("span")
                            .class("cdm-card-label-secondary")
                            .openEnd(); {
                            rm.text(oControl.getSecondaryLabel() + " ");
                        } rm.close("span");
                    }
                    rm.text(oControl.getSecondaryValue());
                    if (oControl.getSecondaryUnit()) {
                        rm.openStart("span")
                            .class("cdm-card-unit-secondary")
                            .openEnd(); {
                            rm.text(" " + oControl.getSecondaryUnit());
                        } rm.close("span");
                    }
                } rm.close("div");
            }

        } rm.close("div");
    };

    return Renderer;
});