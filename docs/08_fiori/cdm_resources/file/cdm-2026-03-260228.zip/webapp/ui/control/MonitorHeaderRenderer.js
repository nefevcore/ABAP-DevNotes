/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */

    Renderer.render = function (rm, oControl) {
        var oMonitorHeader = oControl;
        var id = oMonitorHeader.getId();

        rm.openStart("header", id)
            .style("--logo-size", oMonitorHeader.getLogoSize())
            .class("cdm-monitor-header")
            .openEnd(); {

            /**
             * LOGO - 改用图片渲染
             */
            var logoImage = oMonitorHeader.getLogoImage();
            var logoText = oMonitorHeader.getLogoText();
            rm.openStart("div", id + "-logo")
                .class("cdm-logo-section")
                .openEnd(); {

                if (!!logoImage) {
                    // 使用图片渲染Logo
                    rm.openStart("div", id + "-logoImage")
                        .class("cdm-logo-image")
                        .openEnd(); {
                        rm.openStart("img")
                            .attr("src", logoImage)
                            .attr("alt", logoText || "Logo")
                            .class("cdm-logo-img")
                            .openEnd()
                            .close("img");
                    } rm.close("div");
                }

                if (!!logoText) {
                    rm.openStart("div", id + "-logoText")
                        .class("cdm-logo-text")
                        .openEnd(); {
                        rm.openStart("p").openEnd().text(logoText).close("p");
                    } rm.close("div");
                }
            } rm.close("div");

            /**
             * 标题
             */
            var title = oMonitorHeader.getTitle();
            rm.openStart("div", id + "-title")
                .class("cdm-center-title")
                .openEnd(); {
                rm.text(title);
            } rm.close("div");

            /**
             * 时间戳
             */
            var enableTime = oMonitorHeader.getEnableTime();
            if (!!enableTime) {
                rm.openStart("div", id + "-time")
                    .class("cdm-time-info")
                    .openEnd(); {
                    rm.openStart("div").openEnd().text(oMonitorHeader.getCurrentTime()).close("div");
                } rm.close("div");
            }

        } rm.close("header");
    };

    return Renderer;
});