sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TagRenderer",
], function (
    Control, TagRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.Tag", {

        metadata: {
            properties: {
                "tagCode": {
                    type: "string",
                    defaultValue: ""
                },
                "tagName": {
                    type: "string",
                    defaultValue: ""
                },
            },
            renderer: TagRenderer
        }
    });
});