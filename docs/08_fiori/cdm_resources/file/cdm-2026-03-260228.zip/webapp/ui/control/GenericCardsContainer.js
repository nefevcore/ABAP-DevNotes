sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/GenericCardsContainerRenderer",
], function (
    Control, GenericCardsContainerRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.GenericCardsContainer", {

        metadata: {
            properties: {
                // 布局类型
                layoutType: {
                    type: "string",
                    defaultValue: "flex",
                    values: ["flex", "grid"]
                },

                // Flex布局属性
                flexDirection: {
                    type: "string",
                    defaultValue: "row",
                    values: ["row", "column", "row-reverse", "column-reverse"]
                },
                flexWrap: {
                    type: "string",
                    defaultValue: "wrap",
                    values: ["wrap", "nowrap", "wrap-reverse"]
                },
                justifyContent: {
                    type: "string",
                    defaultValue: "flex-start",
                    values: ["flex-start", "flex-end", "center", "space-between", "space-around", "space-evenly"]
                },
                alignItems: {
                    type: "string",
                    defaultValue: "stretch",
                    values: ["stretch", "flex-start", "flex-end", "center", "baseline"]
                },
                alignContent: {
                    type: "string",
                    defaultValue: "stretch",
                    values: ["stretch", "flex-start", "flex-end", "center", "space-between", "space-around"]
                },
                flexGap: {
                    type: "string",
                    defaultValue: "16px"
                },

                // Grid布局属性
                gridTemplateColumns: {
                    type: "string",
                    defaultValue: "repeat(auto-fill, minmax(250px, 1fr))"
                },
                gridTemplateRows: {
                    type: "string",
                    defaultValue: "auto"
                },
                gridAutoFlow: {
                    type: "string",
                    defaultValue: "row",
                    values: ["row", "column", "row dense", "column dense"]
                },
                gridGap: {
                    type: "string",
                    defaultValue: "16px"
                },
                gridJustifyItems: {
                    type: "string",
                    defaultValue: "stretch",
                    values: ["stretch", "start", "end", "center"]
                },
                gridAlignItems: {
                    type: "string",
                    defaultValue: "stretch",
                    values: ["stretch", "start", "end", "center", "baseline"]
                },

                // 通用属性
                containerWidth: {
                    type: "string",
                    defaultValue: "100%"
                },
                containerHeight: {
                    type: "string",
                    defaultValue: "auto"
                },
                containerPadding: {
                    type: "string",
                    defaultValue: "0"
                },
                containerMargin: {
                    type: "string",
                    defaultValue: "0"
                },
                backgroundColor: {
                    type: "string",
                    defaultValue: "transparent"
                },
                borderStyle: {
                    type: "string",
                    defaultValue: "none",
                    values: ["none", "solid", "dashed", "dotted"]
                },
                borderWidth: {
                    type: "string",
                    defaultValue: "1px"
                },
                borderColor: {
                    type: "string",
                    defaultValue: "#e0e0e0"
                },
                borderRadius: {
                    type: "string",
                    defaultValue: "0"
                },
                boxShadow: {
                    type: "string",
                    defaultValue: "none"
                }
            },
            aggregations: {
                backgrounds: { type: "cdm.ui.control.MonitorBackground", multiple: true, defaultValue: null, singularName: "background" },
                cards: { type: "sap.ui.core.Control", multiple: true, defaultValue: null, singularName: "card" },
            },
            renderer: GenericCardsContainerRenderer
        }
    });
});