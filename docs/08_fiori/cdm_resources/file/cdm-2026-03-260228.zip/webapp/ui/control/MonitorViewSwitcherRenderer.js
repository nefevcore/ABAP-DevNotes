/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        const id = oControl.getId();
        const views = oControl.getViews();
        const buttonMode = oControl.getButtonMode();

        rm.openStart("div", id)
            .class("cdm-view-switcher")
            .class(`cdm-view-switcher--btn-mode-${buttonMode}`)
            .attr("tabindex", "0")
            .openEnd();

        // 渲染所有视图
        views.forEach((view) => {
            rm.renderControl(view);
        });

        // 渲染导航按钮和指示器（仅当有多个视图时）
        if (views.length > 1) {
            this._renderNavigation(rm, oControl, views);
        }

        rm.close("div");
    };

    Renderer._renderNavigation = function (rm, oControl, views) {

        // 导航按钮容器
        rm.openStart("div")
            .class("cdm-view-switcher-nav-container")
            .openEnd();

        // 上一页按钮
        rm.openStart("div")
            .class("cdm-view-switcher-nav-btn cdm-view-switcher-prev-btn")
            .attr("role", "button")
            .attr("tabindex", "0")
            .attr("title", "上一页")
            .attr("aria-label", "切换到上一页")
            .openEnd();

        this._renderArrowIcon(rm, "left");

        rm.close("div");

        // 下一页按钮
        rm.openStart("div")
            .class("cdm-view-switcher-nav-btn cdm-view-switcher-next-btn")
            .attr("role", "button")
            .attr("tabindex", "0")
            .attr("title", "下一页")
            .attr("aria-label", "切换到下一页")
            .openEnd();

        this._renderArrowIcon(rm, "right");

        rm.close("div");

        rm.close("div");

        // 指示器
        rm.openStart("div")
            .class("cdm-view-switcher-indicators")
            .openEnd();

        views.forEach((view, index) => {
            rm.openStart("div")
                .class("cdm-view-switcher-indicator")
                .class(index === oControl.getCurrentViewIndex() ? "active" : "")
                .attr("role", "button")
                .attr("tabindex", "0")
                .attr("title", `切换到第${index + 1}页`)
                .attr("aria-label", `切换到第${index + 1}页`)
                .attr("data-index", index)
                .openEnd();
            rm.close("div");
        });

        rm.close("div");
    };

    Renderer._renderArrowIcon = function (rm, direction) {
        const pathData = direction === "left"
            ? "M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"
            : "M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z";

        rm.openStart("svg")
            .attr("viewBox", "0 0 24 24")
            .attr("width", "72")
            .attr("height", "72")
            .openEnd();

        rm.openStart("path")
            .attr("d", pathData)
            .attr("fill", "currentColor")
            .openEnd()
            .close("path");

        rm.close("svg");
    };

    return Renderer;
});