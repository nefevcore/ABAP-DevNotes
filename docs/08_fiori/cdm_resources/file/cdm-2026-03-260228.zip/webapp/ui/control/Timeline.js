sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TimelineRenderer",
], function (
    Control, TimelineRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.Timeline", {

        metadata: {
            aggregations: {
                items: { type: "cdm.ui.control.TimelineItem", multiple: true, defaultValue: null }
            },
            renderer: TimelineRenderer
        }
    });
});