sap.ui.define([
	"sap/ui/core/Control",
	"cdm/ui/control/MonitorHeaderRenderer",
	"sap/ui/core/format/DateFormat"
], function (
	Control,
	MonitorHeaderRenderer,
	DateFormat
) {
	"use strict";

	return Control.extend("cdm.ui.control.MonitorHeader", {
		metadata: {
			properties: {
				title: { type: "string", defaultValue: "" },
				logoImage: { type: "string", defaultValue: "" },
				logoSize: { type: "string", defaultValue: "80px" },
				logoText: { type: "string", defaultValue: "" },
				enableTime: { type: "boolean", defaultValue: true },
				currentTime: { type: "string", defaultValue: "" },
			},
			renderer: MonitorHeaderRenderer
		},

		init: function () {
			// 初始化定时器
			this._timeTimer = null;
			this._updateTime();
		},

		onBeforeRendering: function () {
			// 渲染前确保时间更新
			this._updateTime();
		},

		onAfterRendering: function () {
			// 渲染后启动定时器
			this._startTimeTimer();
		},

		exit: function () {
			// 清理定时器
			this._clearTimeTimer();
		},

		_updateTime: function () {
			if (this.getEnableTime()) {
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyy年MM月dd日 HH:mm:ss"
				});
				var sCurrentTime = oDateFormat.format(new Date());
				this.setCurrentTime(sCurrentTime);
			}
		},

		_startTimeTimer: function () {
			if (this.getEnableTime()) {
				this._clearTimeTimer();
				this._timeTimer = setInterval(() => {
					this._updateTime();
				}, 1000); // 每秒更新一次
			}
		},

		_clearTimeTimer: function () {
			if (this._timeTimer) {
				clearInterval(this._timeTimer);
				this._timeTimer = null;
			}
		}
	});
});