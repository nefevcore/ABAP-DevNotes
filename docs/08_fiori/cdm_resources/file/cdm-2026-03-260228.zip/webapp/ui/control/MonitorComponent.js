sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/MonitorComponentRenderer",
], function (
    Control,
    MonitorComponentRenderer
) {
    "use strict";

    // 常量定义
    const SCROLL_INTERVAL = 50; // 滚动间隔时间（毫秒）
    const CHECK_INTERVAL = 1000; // 检查间隔时间（毫秒）
    const SCROLL_STEP = 1; // 每次滚动的像素数
    const USER_SCROLL_PAUSE = 2000; // 用户手动滚动后暂停时间（毫秒）

    return Control.extend("cdm.ui.control.MonitorComponent", {
        metadata: {
            properties: {
                title: {
                    type: "string",
                    defaultValue: ""
                },
                gridArea: {
                    type: "string",
                    defaultValue: ""
                },
                borderStyle: {
                    type: "string",
                    defaultValue: "standard",
                    values: ["none", "standard", "transparent", "glow"]
                },
                contentFlexDirection: {
                    type: "string",
                    defaultValue: "column",
                    values: ["row", "column", "row-reverse", "column-reverse"]
                },
                overflow: {
                    type: "string",
                    defaultValue: "auto"
                },
                autoScroll: {
                    type: "boolean",
                    defaultValue: false
                },
                scrollPause: {
                    type: "int",
                    defaultValue: 20
                }
            },
            aggregations: {
                content: {
                    type: "sap.ui.core.Control",
                    multiple: true,
                    defaultValue: null
                }
            },
            renderer: MonitorComponentRenderer
        },

        init: function () {
            this._startScrollInterval = null;
            this._autoScrollInterval = null;
            this._afterRendering = false;
            this._userScrollTimeout = null;
            this._isUserScrolling = false;
            this._lastScrollTop = 0;
        },

        exit: function () {
            this._stopAutoScroll();
            if (this._userScrollTimeout) {
                clearTimeout(this._userScrollTimeout);
                this._userScrollTimeout = null;
            }
        },

        setAutoScroll: function (bValue) {
            this.setProperty("autoScroll", bValue);

            if (bValue) {
                this._startAutoScroll();
            } else {
                this._stopAutoScroll();
            }

            return this;
        },

        onAfterRendering: function () {
            this._afterRendering = true;

            if (this.getAutoScroll()) {
                this._startAutoScroll();
            }

            // 绑定滚动事件监听器
            this._attachScrollListener();
        },

        // 私有方法
        _startAutoScroll: function () {
            this._stopAutoScroll();

            if (!this.getAutoScroll()) {
                return;
            }

            this._startScrollInterval = setInterval(() => {
                this._checkAndStartScroll();
            }, CHECK_INTERVAL);
        },

        _stopAutoScroll: function () {
            if (this._startScrollInterval) {
                clearInterval(this._startScrollInterval);
                this._startScrollInterval = null;
            }

            if (this._autoScrollInterval) {
                clearInterval(this._autoScrollInterval);
                this._autoScrollInterval = null;
            }
        },

        _checkAndStartScroll: function () {
            // 如果已经在滚动，则跳过
            if (this._autoScrollInterval || this._isUserScrolling) {
                return;
            }

            const domRef = this.getDomRef();
            if (!domRef) {
                return;
            }

            const contentDiv = domRef.querySelector(".cdm-component-content");
            if (!contentDiv) {
                return;
            }

            const scrollContainer = contentDiv.firstElementChild;
            if (!scrollContainer) {
                return;
            }

            // 检查是否需要滚动
            if (scrollContainer.scrollHeight <= scrollContainer.clientHeight) {
                return;
            }

            this._startScrollAnimation(scrollContainer);
        },

        _startScrollAnimation: function (scrollContainer) {
            const SCROLL_PAUSE = this.getScrollPause();
            let scrollTop = scrollContainer.scrollTop;
            if (scrollTop === 0) {
                scrollTop = -SCROLL_PAUSE;
            }

            this._autoScrollInterval = setInterval(() => {
                const maxScroll = scrollContainer.scrollHeight + SCROLL_PAUSE;

                if ((scrollTop + scrollContainer.clientHeight) >= maxScroll) {
                    scrollTop = -SCROLL_PAUSE;
                } else {
                    scrollTop += SCROLL_STEP;
                }

                scrollContainer.scrollTop = scrollTop;
            }, SCROLL_INTERVAL);
        },

        _attachScrollListener: function () {
            const domRef = this.getDomRef();
            if (!domRef) {
                return;
            }

            const contentDiv = domRef.querySelector(".cdm-component-content");
            if (!contentDiv) {
                return;
            }

            const scrollContainer = contentDiv.firstElementChild;
            if (!scrollContainer) {
                return;
            }

            // 移除之前的监听器（如果存在）
            if (this._scrollListener) {
                scrollContainer.removeEventListener("scroll", this._scrollListener);
            }

            // 创建新的滚动监听器
            this._scrollListener = this._onUserScroll.bind(this, scrollContainer);
            scrollContainer.addEventListener("scroll", this._scrollListener);
        },

        _onUserScroll: function (scrollContainer) {
            // 如果当前不是自动滚动模式，则不需要处理
            if (!this.getAutoScroll() || !this._autoScrollInterval) {
                return;
            }

            // 检测是否是用户滚动（通过比较当前滚动位置和上次记录的位置）
            const currentScrollTop = scrollContainer.scrollTop;

            // 如果滚动位置变化与自动滚动方向不一致，则认为是用户滚动
            if (Math.abs(currentScrollTop - this._lastScrollTop) > SCROLL_STEP * 2) {
                this._handleUserScroll();
            }

            this._lastScrollTop = currentScrollTop;
        },

        _handleUserScroll: function () {
            // 如果已经在用户滚动状态，重置计时器
            if (this._isUserScrolling) {
                clearTimeout(this._userScrollTimeout);
            } else {
                // 停止自动滚动
                if (this._autoScrollInterval) {
                    clearInterval(this._autoScrollInterval);
                    this._autoScrollInterval = null;
                }
                this._isUserScrolling = true;
            }

            // 设置2秒后恢复自动滚动
            this._userScrollTimeout = setTimeout(() => {
                this._isUserScrolling = false;
                // this._lastScrollTop = 0; // 重置滚动位置记录
                this._checkAndStartScroll(); // 重新检查并开始滚动
            }, USER_SCROLL_PAUSE);
        }
    });
});