sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TimelineItemRenderer",
], function (
    Control,
    TimelineItemRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.TimelineItem", {
        metadata: {
            properties: {
                dateTime: { type: "string", defaultValue: "", group: "Misc" },
                title: { type: "string", defaultValue: "", group: "Misc" },
                text: { type: "string", defaultValue: "", group: "Misc" },
                checked: { type: "boolean", defaultValue: false, group: "Misc" },
            },
            renderer: TimelineItemRenderer
        }
    });
});