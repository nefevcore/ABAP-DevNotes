sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/TabBarRenderer"
], function (
    Control, TabBarRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.TabBar", {
        metadata: {
            properties: {
                selectedKey: { type: "string", defaultValue: "" }
            },
            aggregations: {
                items: { type: "cdm.ui.control.TabBarItem", multiple: true, defaultValue: null }
            },
            events: {
                select: {
                    parameters: {
                        selectedItem: { type: "cdm.ui.control.TabBarItem" },
                        selectedKey: { type: "string" }
                    }
                }
            },
            renderer: TabBarRenderer
        },

        /**
         * @override
         * @returns {void|undefined}
         */
        init: function () {
            this._bEventsAttached = false;
        },

        onAfterRendering: function () {
            if (!this._bEventsAttached) {
                this._attachTabEvents();
                this._bEventsAttached = true;
            }
        },

        _attachTabEvents: function () {
            var items = this.getItems();
            items.forEach((item) => {
                var domRef = item.getTabDomRef();
                if (domRef) {
                    domRef.addEventListener("click", () => {
                        this.setSelectedKey(item.getKey());
                        this.fireSelect({
                            selectedItem: item,
                            selectedKey: item.getKey()
                        });
                    });
                }
            });
        },
    });
});