/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */

// Provides default renderer for control sap.ui.layout.VerticalLayout
sap.ui.define([
], function () {
    "use strict";

    /**
     * ListitemBase renderer.
     *
     * @namespace
     */
    var Renderer = {
        apiVersion: 2
    };

    /**
     * Renders the HTML for the given control, using the provided.
     *
     * {@link sap.ui.core.RenderManager}.
     *
     * @param {sap.ui.core.RenderManager} rm The RenderManager that can be used for writing to the Render-Output-Buffer.
     * @param {sap.ui.core.Control} oControl an object representation of the control that should be rendered.
     * @public
     */
    Renderer.render = function (rm, oControl) {
        var id = oControl.getId();

        rm.openStart("div", id)
            .style("grid-area", oControl.getGridArea())
            .class("cdm-monitor-component")
            .class("cdm-component--border-" + oControl.getBorderStyle())
            .class(oControl.getGridArea())
            .openEnd(); {

            // 标题
            var header = oControl.getTitle();
            if (header) {
                rm.openStart("div")
                    .class("cdm-component-header")
                    .openEnd(); {
                    rm.openStart("div")
                        .class("cdm-component-title")
                        .openEnd(); {
                        rm.text(header);
                    } rm.close("div");
                } rm.close("div");
            }

            // 子组件
            rm.openStart("div")
                .style("display", "flex")
                .style("flex-direction", oControl.getContentFlexDirection())
                .style("overflow", oControl.getOverflow())
                .class("cdm-component-content")
                .openEnd(); {
                var subControls = oControl.getAggregation("content") || [];
                for (let index = 0; index < subControls.length; index++) {
                    rm.renderControl(subControls[index]);
                }
            } rm.close("div");

        } rm.close("div");
    };

    return Renderer;
});