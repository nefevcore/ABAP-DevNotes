sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/MonitorViewSwitcherRenderer"
], function (
    Control,
    MonitorViewSwitcherRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.MonitorViewSwitcher", {
        metadata: {
            properties: {
                // 切换间隔时间（毫秒）
                switchInterval: { type: "int", defaultValue: 120000 },
                // 是否自动切换
                autoSwitch: { type: "boolean", defaultValue: true },
                // 按钮显示模式：always（始终显示）、hover（悬停显示）
                buttonMode: { type: "string", defaultValue: "hover" },
                // 当前显示的视图索引
                currentViewIndex: { type: "int", defaultValue: 0 }
            },
            aggregations: {
                // 要切换的视图集合
                views: { type: "sap.ui.core.mvc.View", multiple: true, singularName: "view" }
            },
            events: {
                // 视图切换事件
                viewSwitch: {
                    parameters: {
                        previousIndex: { type: "int" },
                        currentIndex: { type: "int" },
                        view: { type: "sap.ui.core.mvc.View" }
                    }
                }
            },
            renderer: MonitorViewSwitcherRenderer
        },

        init: function () {
            this._switchTimer = null;
            this._isAnimating = false;
        },

        onAfterRendering: function () {
            this._initializeViews();
            this._bindEvents();

            if (this.getAutoSwitch()) {
                this._startAutoSwitch();
            }
        },

        exit: function () {
            this._stopAutoSwitch();
            this._unbindEvents();
        },

        _initializeViews: function () {
            const views = this.getViews();
            views.forEach((view, index) => {
                view.addStyleClass("cdm-view");
                if (index === this.getCurrentViewIndex()) {
                    view.addStyleClass("cdm-view-show");
                    view.removeStyleClass("cdm-view-hide");
                } else {
                    view.addStyleClass("cdm-view-hide");
                    view.removeStyleClass("cdm-view-show");
                }
            });
        },

        _bindEvents: function () {
            const domRef = this.getDomRef();
            if (!domRef) return;

            // 绑定按钮点击事件
            const prevBtn = domRef.querySelector('.cdm-view-switcher-prev-btn');
            const nextBtn = domRef.querySelector('.cdm-view-switcher-next-btn');

            if (prevBtn) {
                prevBtn.addEventListener('click', this._switchToPrevious.bind(this));
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', this._switchToNext.bind(this));
            }

            // 绑定指示器点击事件
            const indicators = domRef.querySelectorAll('.cdm-view-switcher-indicator');
            indicators.forEach((indicator, index) => {
                indicator.addEventListener('click', () => this.switchToView(index));
            });
        },

        _unbindEvents: function () {
            const domRef = this.getDomRef();
            if (!domRef) return;

            // 移除所有事件监听器
            const prevBtn = domRef.querySelector('.cdm-view-switcher-prev-btn');
            const nextBtn = domRef.querySelector('.cdm-view-switcher-next-btn');

            if (prevBtn) {
                prevBtn.replaceWith(prevBtn.cloneNode(true));
            }

            if (nextBtn) {
                nextBtn.replaceWith(nextBtn.cloneNode(true));
            }
        },

        _startAutoSwitch: function () {
            this._stopAutoSwitch();
            this._switchTimer = setInterval(() => {
                if (!this._isAnimating) {
                    this._switchToNext();
                }
            }, this.getSwitchInterval());
        },

        _stopAutoSwitch: function () {
            if (this._switchTimer) {
                clearInterval(this._switchTimer);
                this._switchTimer = null;
            }
        },

        _switchToPrevious: function () {
            const currentIndex = this.getCurrentViewIndex();
            const totalViews = this.getViews().length;
            const newIndex = (currentIndex - 1 + totalViews) % totalViews;
            this.switchToView(newIndex);
        },

        _switchToNext: function () {
            const currentIndex = this.getCurrentViewIndex();
            const totalViews = this.getViews().length;
            const newIndex = (currentIndex + 1) % totalViews;
            this.switchToView(newIndex);
        },

        switchToView: function (index) {
            const views = this.getViews();
            if (index < 0 || index >= views.length || this._isAnimating) return;

            const previousIndex = this.getCurrentViewIndex();
            const previousView = views[previousIndex];
            const currentView = views[index];

            if (index === previousIndex) return;

            this._isAnimating = true;

            // 暂停自动切换
            if (this.getAutoSwitch()) {
                this._stopAutoSwitch();
            }

            // 设置动画方向
            const isNext = (index > previousIndex) ||
                (previousIndex === views.length - 1 && index === 0);

            previousView?.addStyleClass(isNext ? "cdm-view-hide-left" : "cdm-view-hide-right");
            previousView?.removeStyleClass("cdm-view-show");

            currentView.addStyleClass(isNext ? "cdm-view-hide-right" : "cdm-view-hide-left");
            currentView.removeStyleClass("cdm-view-hide");

            // 执行动画
            setTimeout(() => {
                previousView?.addStyleClass("cdm-view-hide");
                previousView?.removeStyleClass(isNext ? "cdm-view-hide-left" : "cdm-view-hide-right");

                currentView.addStyleClass("cdm-view-show");
                currentView.removeStyleClass(isNext ? "cdm-view-hide-right" : "cdm-view-hide-left");

                // 更新指示器
                this._updateIndicators(previousIndex, index);

                // 更新属性
                this.setProperty("currentViewIndex", index, true);

                // 触发事件
                this.fireViewSwitch({
                    previousIndex: previousIndex,
                    currentIndex: index,
                    view: currentView
                });

                // 恢复自动切换
                if (this.getAutoSwitch()) {
                    this._startAutoSwitch();
                }

                this._isAnimating = false;
            }, 50); // 短暂延迟确保CSS类已应用
        },

        _updateIndicators: function (previousIndex, currentIndex) {
            const indicators = this.getDomRef()?.querySelectorAll('.cdm-view-switcher-indicator');
            if (indicators) {
                if (previousIndex >= 0 && indicators[previousIndex]) {
                    indicators[previousIndex].classList.remove('active');
                }
                if (indicators[currentIndex]) {
                    indicators[currentIndex].classList.add('active');
                }
            }
        },

        setAutoSwitch: function (bAutoSwitch) {
            this.setProperty("autoSwitch", bAutoSwitch, true);
            if (bAutoSwitch) {
                this._startAutoSwitch();
            } else {
                this._stopAutoSwitch();
            }
        },

        setSwitchInterval: function (iInterval) {
            this.setProperty("switchInterval", iInterval, true);
            if (this.getAutoSwitch()) {
                this._stopAutoSwitch();
                this._startAutoSwitch();
            }
        }
    });
});