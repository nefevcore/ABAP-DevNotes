这是您需要的科技风格CSS样式变量展示页面。它使用“cdm-”前缀定义了一套完整的暗色系科技主题变量，并通过卡片、按钮、表单等常见UI组件，直观展示了色彩、字体、阴影等变量的实际效果。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>科技风格 · 变量展示 (cdm- 前缀)</title>
    <!-- 使用简洁的字体，更显科技感 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        /* 科技风格CSS变量定义，前缀 'cdm-' 
           包含色彩、阴影、圆角、渐变、动画、字体等 */
        :root {
            /* 主色 – 深邃的电子蓝紫基调 */
            --cdm-primary-50: #eef5ff;
            --cdm-primary-100: #d9e8ff;
            --cdm-primary-200: #bcd6ff;
            --cdm-primary-300: #8ebaff;
            --cdm-primary-400: #5996ff;
            --cdm-primary-500: #2b6ef0;      /* 主品牌色 */
            --cdm-primary-600: #1a52cc;
            --cdm-primary-700: #1240a3;
            --cdm-primary-800: #0f317a;
            --cdm-primary-900: #0e2659;

            /* 辅助色 – 冷调科技灰 & 青/洋红点缀 */
            --cdm-gray-100: #f0f3f8;
            --cdm-gray-200: #dce2ec;
            --cdm-gray-300: #c2ccda;
            --cdm-gray-400: #9fadc2;
            --cdm-gray-500: #7b8aa4;
            --cdm-gray-600: #5d6b84;
            --cdm-gray-700: #3f4a60;
            --cdm-gray-800: #2a3245;
            --cdm-gray-900: #1a1f2b;
            
            --cdm-cyan: #0dc9cd;
            --cdm-cyan-dark: #07a8b0;
            --cdm-magenta: #d63c9e;
            --cdm-magenta-dark: #b5237e;
            --cdm-success: #2ecc83;
            --cdm-warning: #f2b541;
            --cdm-error: #e7555f;

            /* 背景 & 前景 (科技暗色倾向) */
            --cdm-bg-base: #0d111c;          /* 极深底色 */
            --cdm-bg-surface: #161c2c;        /* 表面卡片色 */
            --cdm-bg-elevated: #1e263b;        /* 更高层级 */
            --cdm-bg-inset: #0a0e18;           /* 嵌入背景 */

            /* 文字颜色 – 高对比且微带冷光 */
            --cdm-text-primary: #f0f4fe;        /* 重要文字 */
            --cdm-text-secondary: #b1c3df;       /* 次要信息 */
            --cdm-text-tertiary: #6f7d9c;        /* 提示/禁用 */
            --cdm-text-inverse: #0d111c;         /* 反色文字 */

            /* 边框 & 分割线 */
            --cdm-border-light: rgba(89, 150, 255, 0.18);    /* 带科技蓝的边框 */
            --cdm-border-strong: rgba(89, 150, 255, 0.4);
            --cdm-border-focus: #5996ff;

            /* 阴影 – 多层次，模仿发光效果 */
            --cdm-shadow-xs: 0 2px 4px rgba(0, 10, 30, 0.6), 0 0 0 1px rgba(89, 150, 255, 0.15);
            --cdm-shadow-sm: 0 4px 8px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(89, 150, 255, 0.25);
            --cdm-shadow-md: 0 8px 16px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(89, 150, 255, 0.3), 0 0 20px rgba(43, 110, 240, 0.3);
            --cdm-shadow-lg: 0 16px 32px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(89, 150, 255, 0.4), 0 0 30px rgba(43, 110, 240, 0.5);
            --cdm-shadow-inner: inset 0 2px 4px rgba(0, 0, 0, 0.8), inset 0 0 0 1px rgba(89, 150, 255, 0.2);

            /* 圆角 – 未来感微圆角结合直角点缀 */
            --cdm-radius-xs: 4px;
            --cdm-radius-sm: 6px;
            --cdm-radius-md: 8px;
            --cdm-radius-lg: 12px;
            --cdm-radius-xl: 20px;
            --cdm-radius-pill: 9999px;
            --cdm-radius-circular: 50%;

            /* 渐变 – 科技常用蓝紫/青绿 */
            --cdm-gradient-1: linear-gradient(135deg, #2b6ef0, #b5237e);
            --cdm-gradient-2: linear-gradient(45deg, #0dc9cd, #2b6ef0);
            --cdm-gradient-3: radial-gradient(circle at top right, #1e263b, #0d111c);

            /* 动画 & 过渡 */
            --cdm-transition-fast: 150ms cubic-bezier(0.2, 0.9, 0.4, 1);
            --cdm-transition-base: 250ms cubic-bezier(0.2, 0.9, 0.4, 1);
            --cdm-transition-slow: 400ms cubic-bezier(0.2, 0.9, 0.4, 1);
            
            /* 字体家族 – 科技感无衬线 */
            --cdm-font-sans: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
            --cdm-font-mono: 'SF Mono', 'Fira Code', 'Cascadia Code', 'Roboto Mono', monospace;
            
            /* 间距系统 (可选，非必须但实用) */
            --cdm-space-1: 4px;
            --cdm-space-2: 8px;
            --cdm-space-3: 12px;
            --cdm-space-4: 16px;
            --cdm-space-5: 24px;
            --cdm-space-6: 32px;
            --cdm-space-8: 48px;
            --cdm-space-10: 64px;
        }

        /* 基础样式应用 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: var(--cdm-bg-base);
            color: var(--cdm-text-primary);
            font-family: var(--cdm-font-sans);
            line-height: 1.5;
            padding: var(--cdm-space-5);
            min-height: 100vh;
            background-image: var(--cdm-gradient-3);
            background-attachment: fixed;
        }

        .container {
            max-width: 1300px;
            margin: 0 auto;
            background-color: rgba(22, 28, 44, 0.6);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-radius: var(--cdm-radius-xl);
            box-shadow: var(--cdm-shadow-lg), inset 0 0 0 1px var(--cdm-border-light);
            padding: var(--cdm-space-6);
            border: 1px solid rgba(89, 150, 255, 0.15);
        }

        /* 标题区域科技感装饰 */
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: var(--cdm-space-6);
            border-bottom: 1px solid var(--cdm-border-light);
            padding-bottom: var(--cdm-space-4);
        }

        .header h1 {
            font-weight: 600;
            font-size: 2.2rem;
            letter-spacing: -0.01em;
            background: var(--cdm-gradient-1);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            text-shadow: 0 0 15px rgba(43, 110, 240, 0.7);
        }

        .chip {
            background: var(--cdm-bg-elevated);
            border-radius: var(--cdm-radius-pill);
            padding: var(--cdm-space-1) var(--cdm-space-3);
            border: 1px solid var(--cdm-primary-400);
            color: var(--cdm-primary-200);
            font-size: 0.9rem;
            font-weight: 500;
            box-shadow: var(--cdm-shadow-xs);
        }

        /* 网格卡片布局 */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: var(--cdm-space-5);
            margin-top: var(--cdm-space-5);
        }

        .card {
            background: var(--cdm-bg-surface);
            border-radius: var(--cdm-radius-lg);
            padding: var(--cdm-space-5);
            box-shadow: var(--cdm-shadow-md);
            border: 1px solid var(--cdm-border-light);
            transition: transform var(--cdm-transition-base), box-shadow var(--cdm-transition-base);
            backdrop-filter: blur(4px);
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: var(--cdm-shadow-lg);
            border-color: var(--cdm-border-strong);
        }

        .card__title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: var(--cdm-space-4);
            display: flex;
            align-items: center;
            gap: var(--cdm-space-2);
            color: var(--cdm-primary-200);
        }

        .card__title::before {
            content: '▌';
            color: var(--cdm-cyan);
            font-weight: 700;
            font-size: 1.5rem;
        }

        /* 色块展示 */
        .color-grid {
            display: flex;
            flex-wrap: wrap;
            gap: var(--cdm-space-2);
            margin-top: var(--cdm-space-3);
        }

        .color-chip {
            width: 50px;
            height: 50px;
            border-radius: var(--cdm-radius-sm);
            box-shadow: var(--cdm-shadow-xs);
            border: 1px solid var(--cdm-border-light);
            display: flex;
            align-items: flex-end;
            justify-content: center;
            font-size: 0.6rem;
            padding: 4px;
            color: white;
            text-shadow: 0 0 5px black;
            font-family: var(--cdm-font-mono);
            background: inherit; /* fallback */
        }

        /* 按钮示例 */
        .btn-group {
            display: flex;
            flex-wrap: wrap;
            gap: var(--cdm-space-3);
            margin: var(--cdm-space-4) 0;
        }

        .btn {
            background: var(--cdm-bg-elevated);
            border: 1px solid var(--cdm-border-light);
            color: var(--cdm-text-primary);
            padding: var(--cdm-space-2) var(--cdm-space-4);
            border-radius: var(--cdm-radius-pill);
            font-weight: 500;
            font-size: 0.9rem;
            cursor: default;
            transition: all var(--cdm-transition-fast);
            box-shadow: var(--cdm-shadow-xs);
            font-family: var(--cdm-font-sans);
        }

        .btn-primary {
            background: var(--cdm-primary-600);
            border-color: var(--cdm-primary-400);
            color: white;
            text-shadow: 0 1px 2px rgba(0,0,0,0.5);
        }

        .btn-cyan {
            background: var(--cdm-cyan-dark);
            border-color: var(--cdm-cyan);
            color: black;
            font-weight: 600;
        }

        .btn-magenta {
            background: var(--cdm-magenta);
            border-color: var(--cdm-magenta-dark);
        }

        .badge {
            display: inline-block;
            background: var(--cdm-primary-800);
            border-radius: var(--cdm-radius-pill);
            padding: 2px var(--cdm-space-2);
            font-size: 0.75rem;
            border: 1px solid var(--cdm-primary-400);
            color: var(--cdm-primary-100);
        }

        /* 文字示例 */
        .text-sample {
            background: var(--cdm-bg-inset);
            padding: var(--cdm-space-4);
            border-radius: var(--cdm-radius-md);
            border-left: 4px solid var(--cdm-cyan);
            box-shadow: var(--cdm-shadow-inner);
            margin: var(--cdm-space-4) 0;
        }

        .text-sample p {
            margin: var(--cdm-space-2) 0;
        }

        .sample-primary {
            color: var(--cdm-text-primary);
        }
        .sample-secondary {
            color: var(--cdm-text-secondary);
        }
        .sample-tertiary {
            color: var(--cdm-text-tertiary);
        }

        .gradient-box {
            height: 60px;
            border-radius: var(--cdm-radius-md);
            margin: var(--cdm-space-3) 0;
            border: 1px solid var(--cdm-border-light);
        }

        /* 表单元素仿科技风格 */
        .input-sample {
            background: var(--cdm-bg-inset);
            border: 1px solid var(--cdm-border-light);
            border-radius: var(--cdm-radius-md);
            padding: var(--cdm-space-3) var(--cdm-space-4);
            color: var(--cdm-text-primary);
            width: 100%;
            font-family: var(--cdm-font-sans);
            box-shadow: var(--cdm-shadow-inner);
            transition: border var(--cdm-transition-fast);
        }

        .input-sample:focus {
            outline: none;
            border-color: var(--cdm-border-focus);
            box-shadow: 0 0 0 3px rgba(89, 150, 255, 0.3);
        }

        .range-sample {
            width: 100%;
            margin: var(--cdm-space-3) 0;
            accent-color: var(--cdm-cyan);
        }

        hr {
            border: none;
            border-top: 1px solid var(--cdm-border-light);
            margin: var(--cdm-space-5) 0;
        }

        .shadow-demo {
            display: flex;
            gap: var(--cdm-space-4);
            flex-wrap: wrap;
        }

        .shadow-box {
            width: 100px;
            height: 80px;
            background: var(--cdm-bg-elevated);
            border-radius: var(--cdm-radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            border: 1px solid var(--cdm-border-light);
        }

        .font-demo {
            font-family: var(--cdm-font-mono);
            background: var(--cdm-bg-inset);
            padding: var(--cdm-space-2);
            border-radius: var(--cdm-radius-sm);
        }

        .variable-badge {
            display: inline-block;
            background: rgba(43, 110, 240, 0.2);
            border-radius: var(--cdm-radius-xs);
            padding: 2px 6px;
            font-family: var(--cdm-font-mono);
            font-size: 0.7rem;
            border: 1px solid var(--cdm-primary-400);
            color: var(--cdm-primary-200);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 头部展示前缀标识 -->
        <div class="header">
            <h1>⚡ cdm- 科技变量 · 极简暗界</h1>
            <div class="chip">前缀 cdm- / v1.0</div>
        </div>

        <!-- 快速概览：色彩核心 -->
        <div class="grid">
            <!-- 主色与辅助色 -->
            <div class="card">
                <div class="card__title">主色 / 辅助色</div>
                <div class="color-grid">
                    <div class="color-chip" style="background: var(--cdm-primary-500);">500</div>
                    <div class="color-chip" style="background: var(--cdm-primary-600);">600</div>
                    <div class="color-chip" style="background: var(--cdm-primary-400);">400</div>
                    <div class="color-chip" style="background: var(--cdm-cyan);">cyan</div>
                    <div class="color-chip" style="background: var(--cdm-magenta);">magenta</div>
                    <div class="color-chip" style="background: var(--cdm-success);">success</div>
                    <div class="color-chip" style="background: var(--cdm-warning);">warn</div>
                    <div class="color-chip" style="background: var(--cdm-error);">error</div>
                </div>
                <div class="variable-badge" style="margin-top:12px;">--cdm-primary-* --cdm-cyan --cdm-magenta</div>
            </div>
            <!-- 灰色阶 -->
            <div class="card">
                <div class="card__title">中性色 / 背景</div>
                <div class="color-grid">
                    <div class="color-chip" style="background: var(--cdm-gray-200); color:black;">200</div>
                    <div class="color-chip" style="background: var(--cdm-gray-400);">400</div>
                    <div class="color-chip" style="background: var(--cdm-gray-600);">600</div>
                    <div class="color-chip" style="background: var(--cdm-gray-800);">800</div>
                </div>
                <div style="display: flex; gap:8px; margin-top:12px;">
                    <div class="color-chip" style="background: var(--cdm-bg-base);">bg-base</div>
                    <div class="color-chip" style="background: var(--cdm-bg-surface);">surface</div>
                    <div class="color-chip" style="background: var(--cdm-bg-elevated);">elevated</div>
                    <div class="color-chip" style="background: var(--cdm-bg-inset);">inset</div>
                </div>
                <div class="variable-badge">--cdm-gray-* --cdm-bg-*</div>
            </div>

            <!-- 文字颜色层次 -->
            <div class="card">
                <div class="card__title">文字颜色</div>
                <div class="text-sample">
                    <p class="sample-primary">◉ --cdm-text-primary 主要文字 (几乎白色)</p>
                    <p class="sample-secondary">◉ --cdm-text-secondary 辅助文字 (淡蓝灰)</p>
                    <p class="sample-tertiary">◉ --cdm-text-tertiary 提示文字 (更灰)</p>
                    <p><span class="badge">反色使用场合</span> <span style="background:var(--cdm-text-primary); color:var(--cdm-text-inverse); padding:2px 6px; border-radius:var(--cdm-radius-xs);">inverse</span></p>
                </div>
                <div class="variable-badge">--cdm-text-primary/secondary/tertiary/inverse</div>
            </div>

            <!-- 渐变 & 阴影 -->
            <div class="card">
                <div class="card__title">渐变 & 阴影</div>
                <div class="gradient-box" style="background: var(--cdm-gradient-1);">--cdm-gradient-1 蓝紫色</div>
                <div class="gradient-box" style="background: var(--cdm-gradient-2);">--cdm-gradient-2 青蓝色</div>
                <div class="shadow-demo">
                    <div class="shadow-box" style="box-shadow: var(--cdm-shadow-xs);">xs</div>
                    <div class="shadow-box" style="box-shadow: var(--cdm-shadow-sm);">sm</div>
                    <div class="shadow-box" style="box-shadow: var(--cdm-shadow-md);">md</div>
                    <div class="shadow-box" style="box-shadow: var(--cdm-shadow-lg);">lg</div>
                </div>
                <div class="variable-badge">--cdm-gradient-* --cdm-shadow-*</div>
            </div>

            <!-- 圆角与边框 -->
            <div class="card">
                <div class="card__title">圆角 & 边框</div>
                <div style="display: flex; flex-wrap: wrap; gap: var(--cdm-space-3);">
                    <div style="width:50px;height:50px;background:var(--cdm-primary-700); border-radius:var(--cdm-radius-xs);"></div>
                    <div style="width:50px;height:50px;background:var(--cdm-primary-700); border-radius:var(--cdm-radius-sm);"></div>
                    <div style="width:50px;height:50px;background:var(--cdm-primary-700); border-radius:var(--cdm-radius-md);"></div>
                    <div style="width:50px;height:50px;background:var(--cdm-primary-700); border-radius:var(--cdm-radius-lg);"></div>
                    <div style="width:50px;height:50px;background:var(--cdm-primary-700); border-radius:var(--cdm-radius-pill);"></div>
                </div>
                <div style="margin-top:12px;">
                    <div style="border:2px dashed var(--cdm-border-light); padding:6px; border-radius:var(--cdm-radius-md);">边框 light</div>
                    <div style="border:1px solid var(--cdm-border-strong); margin-top:8px; padding:6px; border-radius:var(--cdm-radius-md);">边框 strong</div>
                </div>
                <div class="variable-badge">--cdm-radius-* --cdm-border-*</div>
            </div>

            <!-- 按钮 / 交互元素 -->
            <div class="card">
                <div class="card__title">按钮 & 标签</div>
                <div class="btn-group">
                    <span class="btn">基础</span>
                    <span class="btn btn-primary">主按钮</span>
                    <span class="btn btn-cyan">青 Cyan</span>
                    <span class="btn btn-magenta">洋红</span>
                </div>
                <div style="margin: 12px 0;">
                    <span class="badge">推荐</span>
                    <span class="badge" style="background:var(--cdm-cyan-dark);">新功能</span>
                    <span class="badge" style="background:var(--cdm-error);">报错</span>
                </div>
                <div class="variable-badge">--cdm-primary, --cdm-cyan, --cdm-magenta 等</div>
            </div>

            <!-- 表单控件 & 字体 -->
            <div class="card">
                <div class="card__title">输入 / 字体</div>
                <input class="input-sample" type="text" placeholder="--cdm-bg-inset 内部阴影" value="科技输入框">
                <input class="range-sample" type="range" value="60">
                <div style="display:flex; gap:6px; margin-top:12px;">
                    <span class="font-demo" style="font-family:var(--cdm-font-sans);">Sans</span>
                    <span class="font-demo" style="font-family:var(--cdm-font-mono);">Mono</span>
                </div>
                <div class="variable-badge">--cdm-font-sans / mono · 内阴影</div>
            </div>

            <!-- 间距 & 过渡变量（间接展示） -->
            <div class="card">
                <div class="card__title">间距 & 过渡</div>
                <div style="display: flex; align-items: center; gap: var(--cdm-space-2);">
                    <div style="width: var(--cdm-space-4); height: var(--cdm-space-4); background: var(--cdm-cyan);"></div>
                    <span>space-4 (16px)</span>
                </div>
                <div style="display: flex; align-items: center; gap: var(--cdm-space-4); margin-top:8px;">
                    <div style="width: var(--cdm-space-6); height: var(--cdm-space-6); background: var(--cdm-magenta);"></div>
                    <span>space-6 (32px)</span>
                </div>
                <div style="margin-top:16px; transition: all var(--cdm-transition-fast);" class="badge">悬停卡片的过渡使用了 --cdm-transition-base</div>
                <div class="variable-badge">--cdm-space-* --cdm-transition-*</div>
            </div>
        </div>

        <hr>
        <!-- 底部完整变量名列表 -->
        <div style="display: flex; flex-wrap: wrap; gap: 8px 16px; justify-content: center; opacity: 0.8; font-size: 0.8rem;">
            <span class="variable-badge">--cdm-primary-{50..900}</span>
            <span class="variable-badge">--cdm-gray-{100..900}</span>
            <span class="variable-badge">--cdm-cyan / -dark</span>
            <span class="variable-badge">--cdm-magenta / -dark</span>
            <span class="variable-badge">--cdm-bg-base/surface/elevated/inset</span>
            <span class="variable-badge">--cdm-text-*</span>
            <span class="variable-badge">--cdm-border-*</span>
            <span class="variable-badge">--cdm-shadow-{xs,sm,md,lg,inner}</span>
            <span class="variable-badge">--cdm-radius-{xs,sm,md,lg,xl,pill,circular}</span>
            <span class="variable-badge">--cdm-gradient-1/2/3</span>
            <span class="variable-badge">--cdm-transition-{fast,base,slow}</span>
            <span class="variable-badge">--cdm-font-sans/mono</span>
            <span class="variable-badge">--cdm-space-{1,2,3,4,5,6,8,10}</span>
        </div>

        <!-- 最后一行显示发光文字 -->
        <div style="text-align: center; margin-top: var(--cdm-space-6); color: var(--cdm-text-secondary);">
            <span style="text-shadow: 0 0 8px var(--cdm-cyan);">❖ 所有变量以 "cdm-" 为前缀，适应未来科技界面 ❖</span>
        </div>
    </div>
</body>
</html>
```

### 设计理念与视觉亮点

这份样式变量不仅定义了颜色，更构建了一套完整的视觉语言。您可以快速了解其设计思路：

- **色彩系统**：以深邃的电子蓝紫为主色，搭配冷调灰阶和青、洋红点缀，营造出专业的科技感氛围。所有色彩变量均包含从浅到深的阶梯，方便您灵活选用。
- **质感与层次**：通过多层次的**阴影变量**（如 `--cdm-shadow-md`）模拟发光效果，结合微妙的**边框光晕**（`--cdm-border-light`）和**背景色层**（`--cdm-bg-surface`），让界面元素富有立体感和通透感。
- **交互与动效**：预设了快、中、慢三档**过渡曲线变量**（`--cdm-transition-base`）。页面中的卡片在悬停时，会平稳地抬高并增强阴影，这正是这些变量的直观体现。
