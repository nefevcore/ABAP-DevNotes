我来帮你解决这两个问题：

## 问题分析

1. **白屏问题**：由于两个视图同时进行透明度变化，中间会出现两个视图都半透明的状态，导致背景（白色）透出来
2. **动画方向问题**：旧页面向右移出，新页面从左进入，看起来像两个页面分离而不是连续滚动

## 解决方案

### 1. 修改CSS动画效果

```css cdm/webapp/css/cdm/cdm-view-switcher.css
/* 修改视图样式 */
.cdm-view {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    transition: transform 1.5s ease;
    opacity: 1; /* 始终保持不透明 */
}

.cdm-view-show {
    transform: translateX(0);
    z-index: 2;
}

.cdm-view-hide {
    transform: translateX(-100%); /* 向左移出 */
    z-index: 1;
}

/* 添加新的视图状态 */
.cdm-view-next {
    transform: translateX(100%); /* 新页面从右侧进入 */
    z-index: 1;
}

/* 移除旧的透明度相关样式 */
/* .cdm-view-show 和 .cdm-view-hide 中的 opacity 相关代码已移除 */
```

### 2. 修改JavaScript控制逻辑

```javascript cdm/webapp/ui/control/MonitorViewSwitcher.js
// ... existing code ...

switchToView: function (index) {
    const views = this.getViews();
    if (index < 0 || index >= views.length) return;

    const previousIndex = this.getCurrentViewIndex();
    const previousView = views[previousIndex];
    const currentView = views[index];

    // 先设置新页面的初始位置（从右侧进入）
    currentView.addStyleClass("cdm-view-next");
    currentView.removeStyleClass("cdm-view-hide");
    
    // 使用requestAnimationFrame确保DOM更新
    requestAnimationFrame(() => {
        // 移除新页面的初始位置类，触发动画
        currentView.removeStyleClass("cdm-view-next");
        currentView.addStyleClass("cdm-view-show");
        
        // 旧页面向左移出
        if (previousView) {
            previousView.removeStyleClass("cdm-view-show");
            previousView.addStyleClass("cdm-view-hide");
        }
    });

    // 更新指示器
    this._updateIndicators(previousIndex, index);

    // 更新属性
    this.setProperty("currentViewIndex", index, true);

    // 触发事件
    this.fireViewSwitch({
        previousIndex: previousIndex,
        currentIndex: index,
        view: currentView
    });
},

// 修改初始化视图的方法
_initializeViews: function () {
    const views = this.getViews();
    views.forEach((view, index) => {
        view.addStyleClass("cdm-view");
        if (index === this.getCurrentViewIndex()) {
            view.addStyleClass("cdm-view-show");
            view.removeStyleClass("cdm-view-hide");
            view.removeStyleClass("cdm-view-next");
        } else {
            // 其他视图都放在右侧等待
            view.addStyleClass("cdm-view-next");
            view.removeStyleClass("cdm-view-show");
            view.removeStyleClass("cdm-view-hide");
        }
    });
},

// ... existing code ...
```

### 3. 可选：添加更流畅的滚动效果

如果你想要更流畅的连续滚动效果，可以修改CSS：

```css cdm/webapp/css/cdm/cdm-view-switcher.css
/* 可选：添加连续滚动效果 */
.cdm-view {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    transition: transform 1.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    opacity: 1;
}

/* 可选：添加3D效果 */
.cdm-view-switcher {
    perspective: 1000px; /* 添加透视效果 */
}

.cdm-view {
    transform-style: preserve-3d;
    backface-visibility: hidden; /* 防止闪烁 */
}

/* 可选：淡入淡出效果（如果还是想要透明度变化） */
.cdm-view-show {
    transform: translateX(0);
    opacity: 1;
    z-index: 2;
}

.cdm-view-hide {
    transform: translateX(-100%);
    opacity: 0.8; /* 稍微保留一点透明度，避免完全消失 */
    z-index: 1;
}

.cdm-view-next {
    transform: translateX(100%);
    opacity: 0.8;
    z-index: 1;
}
```

## 主要改进

1. **解决白屏问题**：
   - 移除透明度过渡，只使用transform
   - 确保页面始终不透明（opacity: 1）

2. **改进动画方向**：
   - 旧页面向左移出（translateX(-100%)）
   - 新页面从右侧进入（translateX(100%)）
   - 形成连续向左滚动的效果

3. **优化动画流程**：
   - 使用requestAnimationFrame确保动画顺序
   - 先设置新页面位置，再触发动画

这样修改后，页面切换会像连续向左滚动的幻灯片一样，不会出现白屏，动画也更自然流畅。
