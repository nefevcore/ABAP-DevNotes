sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "cdm/services/ServiceManager",
    "cdm/ui/control/TableUtil",
], (Controller,
    /** @type {cdm.services.ServiceManager} */ ServiceMnager,
    CdmTableUtil
) => {
    "use strict";

    return Controller.extend("cdm.controller.S05", {
        onInit() {
            this.api = ServiceMnager.createMonitorService(this.getOwnerComponent().getModel());
        },

        /**
         * @override
         */
        onAfterRendering: function () {
            this._setup_all_components();
            this._setup_timer();
        },

        /**
         * 测试组件是否能正常处理
         */
        _setup_all_components: function () {
            this._setup_S05_01();
            this._setup_S05_02();
            this._setup_S05_03();
            this._setup_S05_04();
            this._setup_S05_05();
            this._setup_S05_06();
            this._setup_S05_07();
            // this._setup_S05_08();
            // this._setup_S05_09();
        },

        _setup_timer: function () {
            this.api.getComponentOption("CONFIG").then((data) => {
                // setInterval(() => this._update_S05_02(), (data.S05_02 && data.S05_02.interval) ? data.S05_02.interval : 5000);
            });
        },

        _setup_S05_01: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_01");

            this.api.getComponentOption("S05_01").then((data) => {
                oModel.setData({ aResponseTimes: data });
            });
        },

        _setup_S05_02: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_02");

            // this.api.getComponentOption("S05_02").then((data) => {
            //     oModel.setData({ echartOption: data });
            // });

            // 生成模拟数据（0-24点）
            const hours = Array.from({ length: 25 }, (_, i) => `${i}:00`);

            // 响应时长数据（蓝色）
            const responseData = [
                5, 3, 2, 1, 2, 4, 8, 15, 25, 30, 28, 25,
                22, 20, 18, 20, 25, 30, 35, 28, 20, 15, 10, 6, 4
            ];

            // 解决时长数据（绿色）
            const resolutionData = [
                8, 6, 5, 4, 5, 7, 12, 20, 35, 40, 38, 35,
                30, 28, 25, 28, 35, 40, 45, 38, 30, 22, 15, 10, 7
            ];

            // 配置项
            const option = {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross',
                        label: {
                            backgroundColor: '#6a7985'
                        }
                    },
                    formatter: function (params) {
                        let result = `时间: ${params[0].name}<br/>`;
                        params.forEach(item => {
                            const color = item.color;
                            const value = item.value;
                            const seriesName = item.seriesName;
                            result += `<span style="display:inline-block;margin-right:5px;border-radius:10px;width:10px;height:10px;background-color:${color}"></span>`;
                            result += `${seriesName}: ${value}分钟<br/>`;
                        });
                        return result;
                    }
                },
                legend: {
                    data: ['响应时长', '解决时长'],
                    bottom: 0
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '20%',
                    top: '10%',
                    containLabel: true
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: hours,
                    // name: '时间',
                    nameLocation: 'middle',
                    nameGap: 30,
                    axisLabel: {
                        interval: 2,
                        fontSize: 12,
                        color: '#e0e7ff'
                    }
                },
                yAxis: {
                    type: 'value',
                    // name: '时长（分钟）',
                    nameLocation: 'middle',
                    nameGap: 40,
                    axisLabel: {
                        formatter: '{value}',
                        color: '#e0e7ff'
                    }
                },
                series: [
                    {
                        name: '响应时长',
                        type: 'line',
                        smooth: true,
                        stack: 'Total',
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: 'rgba(64, 158, 255, 0.8)' },
                                { offset: 1, color: 'rgba(64, 158, 255, 0.1)' }
                            ])
                        },
                        lineStyle: {
                            width: 3,
                            color: '#409EFF'
                        },
                        itemStyle: {
                            color: '#409EFF'
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: responseData
                    },
                    {
                        name: '解决时长',
                        type: 'line',
                        smooth: true,
                        stack: 'Total',
                        areaStyle: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: 'rgba(103, 194, 58, 0.8)' },
                                { offset: 1, color: 'rgba(103, 194, 58, 0.1)' }
                            ])
                        },
                        lineStyle: {
                            width: 3,
                            color: '#67C23A'
                        },
                        itemStyle: {
                            color: '#67C23A'
                        },
                        emphasis: {
                            focus: 'series'
                        },
                        data: resolutionData
                    }
                ]
            };

            oModel.setData({ echartOption: option });
        },

        _setup_S05_03: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_03");

            this.api.getComponentOption("S05_03").then((data) => {
                oModel.setData({ aReturnReasons: data });
            });
        },

        _setup_S05_04: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_04");

            this.api.getComponentOption("S05_04").then((data) => {
                oModel.setData(data);
            });
        },

        _setup_S05_05: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_05");

            this.api.getComponentOption("S05_05").then((data) => {
                data.forEach((item) => {
                    item.iconSrc = "./images/TransitCard.png";
                });
                oModel.setData({ aTransitCards: data });
            });
        },

        _setup_S05_06: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_06");

            this.api.getComponentOption("S05_06").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S05_07: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_07");

            this.api.getComponentOption("S05_07").then((data) => {
                const colors = CdmTableUtil.getColors();
                const colorClasses = CdmTableUtil.getColorClasses();

                // 从Option中提取数据并进行增强处理
                var seriesData = data.series[0].data;
                seriesData.forEach((item, index) => {
                    item.itemStyle = {
                        color: colors[index < 10 ? index % colors.length : 10]
                    };
                });
                data.series[0].data = seriesData;

                // 表格数据
                var total = seriesData.reduce((sum, item) => sum + item.value, 0);
                var aSuspendedDocs = seriesData.map((item, index) => {
                    var ratio = total > 0 ? (item.value / total * 100).toFixed(2) : 0;
                    return {
                        docType: item.name,
                        number: item.value,
                        ratio: `${ratio}%`,
                        color: index < 10 ? colorClasses[index % colorClasses.length] : colorClasses[10]
                    };
                });

                oModel.setData({
                    aSuspendedDocs: aSuspendedDocs,
                    echartOption: data
                });
            });

            this.getView().byId("id_S05_07_SuspendedDoc_Table").attachRowsUpdated((oEvent) => {
                var aRows = oEvent.getSource().getRows();
                aRows.forEach((oRow) => {
                    var oCtx = oRow.getBindingContext("S05_07");
                    if (oCtx) {
                        var oItem = oCtx.getObject();
                        oRow.getCells().forEach((oCell) => {
                            var sFieldname = oCell.data("fieldname");
                            if (sFieldname === "docType") {
                                CdmTableUtil.setColorBlockToCell(oCell, oCell.data("color"));
                            }
                        });
                    }
                });
            });
        },

        _setup_S05_08: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_08");

            this.api.getComponentOption("S05_08").then((data) => {
                oModel.setData({ tags: data.tags });
            });
        },

        _setup_S05_09: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S05_09");

            this.api.getComponentOption("S05_09").then((data) => {
                oModel.setData({ tags: data.tags });
            });
        },
    });
});