sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "cdm/services/ServiceManager",
], (Controller,
    /** @type {cdm.services.ServiceManager} */ ServiceMnager
) => {
    "use strict";

    return Controller.extend("cdm.controller.S06", {
        onInit() {
            this.api = ServiceMnager.createMonitorService(this.getOwnerComponent().getModel());
        },

        /**
         * @override
         */
        onAfterRendering: function () {
            this._setup_all_components();
            this._setup_timer();
        },

        /**
         * 测试组件是否能正常处理
         */
        _setup_all_components: function () {
            this._setup_S06_01();
            this._setup_S06_02();
            this._setup_S06_03();
            this._setup_S06_04();
            this._setup_S06_05();
            this._setup_S06_06();
        },

        _setup_timer: function () {
            // this.api.getComponentOption("CONFIG").then((data) => {
            //     setInterval(() => this._update_S06_02(), (data.S06_02 && data.S06_02.interval) ? data.S06_02.interval : 5000);
            // });
        },

        _setup_S06_01: function () {
            // var oModel = new sap.ui.model.json.JSONModel();
            // this.getView().setModel(oModel, "S06_01");

            // this.api.getComponentOption("S06_01").then((data) => {
            //     oModel.setData({ aTimelines: data.timelines });
            // });
        },

        _setup_S06_02: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S06_02");

            // 数据（示例数据，实际使用时请替换为真实数据）
            const data = [
                { name: '鄂尔多斯供电公司', value: 185 },
                { name: '乌兰察布供电公司', value: 162 },
                { name: '包头供电公司', value: 150 },
                { name: '阿拉善供电公司', value: 135 },
                { name: '蒙古超高压供电公司', value: 128 },
                { name: '巴彦淖尔供电公司', value: 120 },
                { name: '薛家湾供电公司', value: 115 },
                { name: '呼和浩特供电公司', value: 98 },
                { name: '乌海供电公司', value: 85 },
                { name: '锡林郭勒供电公司', value: 76 },
                { name: '集团总部', value: 52 }
            ];

            // 按数量从大到小排序
            data.sort((a, b) => a.value - b.value);

            // 提取名称和数值数组
            const names = data.map(item => item.name);
            const values = data.map(item => item.value);

            // 配置项
            const option = {
                grid: {
                    left: '5%',
                    right: '5%',
                    top: '10',
                    bottom: '10',
                    containLabel: true
                },
                xAxis: {
                    type: 'value',
                    axisLabel: {
                        fontSize: 12,
                        color: "#f0f5ff"
                    },
                    splitLine: {
                        show: true
                    }
                },
                yAxis: {
                    type: 'category',
                    data: names,
                    axisLabel: {
                        fontSize: 13,
                        // margin: 10,
                        color: "#f0f5ff"
                    },
                    axisTick: {
                        show: false
                    }
                },
                series: [
                    {
                        type: 'bar',
                        data: values,
                        label: {
                            show: true,
                            position: 'right',
                            fontSize: 12,
                            fontWeight: 'bold',
                            color: "#f0f5ff"
                        },
                        itemStyle: {
                            color: function (params) {
                                // 创建从#0B789A到#03DDF5的渐变
                                // 根据数据索引计算渐变比例
                                const totalBars = data.length;
                                const index = params.dataIndex;

                                // 计算渐变位置（0-1之间）
                                const position = index / (totalBars - 1);

                                // 返回渐变颜色
                                return {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 1,
                                    y2: 0,
                                    colorStops: [
                                        {
                                            offset: 0,
                                            color: '#0B789A' // 起始颜色（深蓝色）
                                        },
                                        {
                                            offset: position, // 根据位置动态调整渐变
                                            color: `rgba(3, 221, 245, ${0.7 + position * 0.3})` // 中间过渡
                                        },
                                        {
                                            offset: 1,
                                            color: '#03DDF5' // 结束颜色（浅蓝色）
                                        }
                                    ]
                                };
                            }
                        },
                        barWidth: '30%',
                        emphasis: {
                            itemStyle: {
                                color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                                    { offset: 0, color: '#0B789A' },
                                    { offset: 0.5, color: '#0A8CAF' },
                                    { offset: 1, color: '#03DDF5' }
                                ]),
                                shadowBlur: 10,
                                shadowColor: 'rgba(3, 221, 245, 0.5)'
                            }
                        }
                    }
                ],
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    },
                    formatter: '{b}: {c}',
                    backgroundColor: 'rgba(11, 120, 154, 0.8)',
                    borderColor: '#03DDF5',
                    textStyle: {
                        color: '#fff'
                    }
                }
            };

            oModel.setData({ echartOption: option });
        },

        _setup_S06_03: function () {
            // var oModel = new sap.ui.model.json.JSONModel();
            // this.getView().setModel(oModel, "S06_03");
            // oModel.setData({ aPaymentCards: aPaymentCards });
        },

        _setup_S06_04: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S06_04");
            // 月份数据
            const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

            // 初始数据（模拟结算量）
            let settlementData = [12500, 13200, 10100, 14300, 18900, 19300, 23400, 27800, 22000, 19500, 16700, 15400];

            // 配置项
            const option = {
                // 提示框配置
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    },
                    formatter: function (params) {
                        return `${params[0].name}<br/>结算量: ${params[0].value.toLocaleString()}`;
                    }
                },

                // 网格配置
                grid: {
                    left: '3%',
                    right: '3%',
                    bottom: '10',
                    top: '10',
                    containLabel: true
                },

                // X轴配置
                xAxis: {
                    type: 'category',
                    data: months,
                    axisLabel: {
                        fontSize: 14,
                        color: "#f0f5ff"
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#ddd'
                        }
                    },
                    axisTick: {
                        alignWithLabel: true
                    }
                },

                // Y轴配置
                yAxis: {
                    type: 'value',
                    name: '支付金额',
                    axisLabel: {
                        fontSize: 14,
                        color: "#f0f5ff",
                        formatter: function (value) {
                            if (value >= 10000) {
                                return (value / 10000) + '万';
                            }
                            return value;
                        }
                    },
                    axisLine: {
                        show: true,
                        lineStyle: {
                            color: '#ddd'
                        }
                    },
                    splitLine: {
                        lineStyle: {
                            color: '#f0f0f0',
                            type: 'dashed'
                        }
                    }
                },

                // 系列配置
                series: [
                    {
                        type: 'bar',
                        barWidth: '30%',
                        data: settlementData,
                        itemStyle: {
                            // 使用从#0B789A到#03DDF5的渐变颜色
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [
                                    { offset: 0, color: '#0B789A' },
                                    { offset: 1, color: '#03DDF5' }
                                ]
                            },
                            // borderRadius: [4, 4, 0, 0]  // 圆角效果
                        },
                        // 标签配置
                        label: {
                            show: true,
                            position: 'top',
                            color: "#f0f5ff",
                            fontWeight: 'bold',
                            formatter: function (params) {
                                const value = params.value;
                                if (value >= 10000) {
                                    return (value / 10000).toFixed(1) + '万';
                                }
                                return value;
                            }
                        },
                        // 鼠标悬停效果
                        emphasis: {
                            itemStyle: {
                                shadowColor: 'rgba(11, 120, 154, 0.5)',
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowOffsetY: 0
                            }
                        }
                    }
                ]
            };

            oModel.setData({ echartOption: option });
        },

        _setup_S06_05: function () {
            // var oModel = new sap.ui.model.json.JSONModel();
            // this.getView().setModel(oModel, "S06_05");

            // this.api.getComponentOption("S06_05").then((data) => {
            //     oModel.setData({ echartOption: data });
            // });
        },

        _setup_S06_06: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S06_06");

            // this.api.getComponentOption("S06_06").then((data) => {
            //     oModel.setData({ tags: data.tags });
            // });

            var aUserPayments = [
                { username: "梁欣", paymentCount: "113" },
                { username: "李常诚", paymentCount: "423" },
                { username: "李凯军", paymentCount: "834" },
                { username: "武思宇", paymentCount: "46" },
                { username: "孙婧", paymentCount: "132" },
                { username: "梁欣", paymentCount: "113" },
                { username: "李常诚", paymentCount: "423" },
                { username: "李凯军", paymentCount: "834" },
                { username: "武思宇", paymentCount: "46" },
                { username: "孙婧", paymentCount: "132" },
                { username: "梁欣", paymentCount: "113" },
                { username: "李常诚", paymentCount: "423" },
                { username: "李凯军", paymentCount: "834" },
                { username: "武思宇", paymentCount: "46" },
                { username: "孙婧", paymentCount: "132" },
            ];
            oModel.setData({ aUserPayments: aUserPayments });
        },
    });
});