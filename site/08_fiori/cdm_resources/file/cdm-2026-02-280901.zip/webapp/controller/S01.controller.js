sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "cdm/services/ServiceManager",
    "cdm/ui/control/TableUtil",
], (Controller,
    /** @type {cdm.services.ServiceManager} */ ServiceMnager,
    CdmTableUtil
) => {
    "use strict";

    return Controller.extend("cdm.controller.S01", {
        onInit() {
            /** @type {cdm.services.api.MonitorService} */
            this.api = ServiceMnager.createMonitorService(this.getOwnerComponent().getModel());
        },

        /**
         * @override
         */
        onAfterRendering: function () {
            this._setup_all_components();
            this._setup_timer();
        },

        /**
         * 测试组件是否能正常处理
         */
        _setup_all_components: function () {
            this._setup_S01_01();
            this._setup_S01_02();
            this._setup_S01_03();
            this._setup_S01_04();
            this._setup_S01_05();
            this._setup_S01_06();
        },

        _setup_timer: function () {
            this.api.getComponentOption("CONFIG").then((data) => {
                setInterval(() => this._update_S01_02(), (data.S01_02 && data.S01_02.interval) ? data.S01_02.interval : 5000);
            });
        },

        _setup_S01_01: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_01");

            this.api.getComponentOption("S01_01").then((data) => {
                oModel.setData({ aTimelines: data.timelines });
            });
        },

        _setup_S01_02: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_02");

            var oGeoModel = new sap.ui.model.json.JSONModel("./geo/150000.geo.json");
            oGeoModel.attachRequestCompleted(() => {
                echarts.registerMap('innerMongolia', oGeoModel.getData());
                this.api.getComponentOption("S01_02").then((data) => {
                    var oData = { groups: data.groups };

                    const oLocationMap = {
                        HH: { name: '呼和浩特市', value: [111.749, 40.842, 0] },
                        BT: { name: '包头市', value: [109.846, 40.657, 0] },
                        WH: { name: '乌海市', value: [106.796, 39.655, 0] },
                        CF: { name: '赤峰市', value: [118.889, 42.257, 0] },
                        TL: { name: '通辽市', value: [122.265, 43.617, 0] },
                        EE: { name: '鄂尔多斯市', value: [109.787, 39.608, 0] },
                        HL: { name: '呼伦贝尔市', value: [119.766, 49.216, 0] },
                        BY: { name: '巴彦淖尔市', value: [107.388, 40.743, 0] },
                        WL: { name: '乌兰察布市', value: [113.132, 40.994, 0] },
                        XA: { name: '兴安盟', value: [122.069, 46.077, 0] },
                        XL: { name: '锡林郭勒盟', value: [116.091, 43.934, 0] },
                        AL: { name: '阿拉善盟', value: [105.702, 38.847, 0] },
                    };

                    oData.groups.forEach(group => {
                        const areaCountMap = {};

                        // 统计每个地区的公司数量
                        group.companys.forEach(company => {
                            const area = company.area;
                            if (!areaCountMap[area]) {
                                areaCountMap[area] = {
                                    name: oLocationMap[area].name,
                                    value: [...oLocationMap[area].value]
                                };
                            }
                            areaCountMap[area].value[2]++;
                        });

                        // 过滤出有公司的地区并赋值给group.data
                        group.data = Object.values(areaCountMap).filter(
                            item => item.value[2] > 0
                        );
                    });

                    oData.geoEchartOption = this._getImpcGeoEchartOption();
                    oData.currentGroup = 0;
                    oData.geoEchartOption.series[0].data = oData.groups[oData.currentGroup].data;
                    oModel.setData(oData);
                });
            });
        },

        _update_S01_02: function () {
            var oModel = this.getView().getModel("S01_02");
            var oData = oModel.getData();
            if (!oModel || !oData || !oData.groups)
                return;

            var next_idx = (oData.currentGroup + 1) % 3;
            oData.currentGroup = next_idx;

            var aOnlineCardIds = ['id_S01_02_card1_GenericCard', 'id_S01_02_card2_GenericCard', 'id_S01_02_card3_GenericCard'];
            aOnlineCardIds.forEach((card_id, index) => {
                this.byId(card_id).setSelected(index === next_idx);
            });

            var animationOption = {
                series: [{
                    data: oData.groups[next_idx].data,
                    itemStyle: {
                        color: ['#FFE066', '#32FFE4', '#FF6BFF'][next_idx]
                    },
                }]
            };
            oData.geoEchartOption = animationOption;

            oModel.setData(oData);
        },

        _getImpcGeoEchartOption: function () {
            return {
                animation: true, // 开启动画
                animationDuration: 2000, // 动画时长
                animationEasing: 'cubicInOut', // 缓动函数
                animationDurationUpdate: 2000, // 数据更新动画时长
                animationEasingUpdate: 'cubicInOut', // 更新缓动函数

                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        if (params.seriesType === 'effectScatter') {
                            return `${params.name}<br/>数值: ${params.value[2]}`;
                        }
                        return params.name;
                    }
                },

                geo: {
                    map: 'innerMongolia',
                    roam: false, // 限制用户操作地图，仅显示
                    zoom: 1.2,
                    center: [113, 45.5],
                    label: {
                        emphasis: {
                            show: true,
                            color: '#e0e7ff'
                        }
                    },
                    itemStyle: {
                        normal: {
                            areaColor: '#213c80',
                            borderColor: '#355fba',
                            borderWidth: 1
                        },
                        emphasis: {
                            areaColor: '#3a7afe'
                        }
                    }
                },
                series: [{
                    type: 'effectScatter',
                    coordinateSystem: 'geo',
                    data: [],
                    symbolSize: function (params) {
                        const value = params[2];
                        // 大部分数值集中在1-4之间，但有2个较大的异常值（9, 10, 27）。为了让散点图更清晰可读，需要设计一个合理的symbolSize计算函数
                        // 使用对数缩放，让大小差异更平缓
                        return Math.log(value + 1) * 8 + 3;
                    },
                    showEffectOn: 'render',
                    rippleEffect: {
                        brushType: 'stroke',
                        period: 12,
                        scale: 8
                    },
                    hoverAnimation: true,
                    itemStyle: {
                        color: ['#FFE066', '#32FFE4', '#FF6BFF'][0]
                    },
                    zlevel: 1
                }]
            };
        },

        _setup_S01_03: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_03");

            this.api.getComponentOption("S01_03").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S01_04: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_04");

            this.api.getComponentOption("S01_04").then((data) => {
                oModel.setData({ text: data.text });
            });
        },

        _setup_S01_05: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_05");

            this.api.getComponentOption("S01_05").then((data) => {
                oModel.setData({ echartOption: data });
            });
        },

        _setup_S01_06: function () {
            var oModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oModel, "S01_06");

            this.api.getComponentOption("S01_06").then((data) => {
                oModel.setData({ tags: data.tags });
            });
        },
    });
});