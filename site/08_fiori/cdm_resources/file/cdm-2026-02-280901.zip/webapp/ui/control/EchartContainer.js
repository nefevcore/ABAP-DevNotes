
sap.ui.define([
	"sap/ui/core/Control",
	"cdm/libs/echarts/echarts-min",
	"cdm/ui/control/EchartContainerRenderer",
], function (
	Control,
	__echarts, // echarts是全局的，这里随便给个名称别污染全局就行
	EchartContainerRenderer
) {
	"use strict";

	// Echart主题编辑器
	// https://echarts.apache.org/zh/theme-builder.html

	// 从CSS变量获取颜色值的辅助函数
	const getCssVariable = (variableName) => {
		return getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
	};

	// 获取所有需要的CSS变量值
	const getCssVariables = () => {
		return {
			'--cdm-primary-bg': getCssVariable('--cdm-primary-bg'),
			'--cdm-secondary-bg': getCssVariable('--cdm-secondary-bg'),
			'--cdm-header-bg': getCssVariable('--cdm-header-bg'),
			'--cdm-accent-color': getCssVariable('--cdm-accent-color'),
			'--cdm-accent-gradient': getCssVariable('--cdm-accent-gradient'),
			'--cdm-border-color': getCssVariable('--cdm-border-color'),
			'--cdm-text-primary': getCssVariable('--cdm-text-primary'),
			'--cdm-text-secondary': getCssVariable('--cdm-text-secondary'),
			'--cdm-text-accent': getCssVariable('--cdm-text-accent'),
			'--cdm-text-table-header': getCssVariable('--cdm-text-table-header'),
			'--cdm-scrollbar-thumb': getCssVariable('--cdm-scrollbar-thumb'),
			'--cdm-scrollbar-track': getCssVariable('--cdm-scrollbar-track'),
			'--cdm-scrollbar-hover': getCssVariable('--cdm-scrollbar-hover'),
			'--cdm-logo-icon-color': getCssVariable('--cdm-logo-icon-color'),
			'--cdm-metric-card-bg-start': getCssVariable('--cdm-metric-card-bg-start'),
			'--cdm-metric-card-bg-end': getCssVariable('--cdm-metric-card-bg-end'),
			'--cdm-table-header-bg': getCssVariable('--cdm-table-header-bg'),
			'--cdm-nested-component-bg': getCssVariable('--cdm-nested-component-bg'),
			'--cdm-nested-component-hover-bg': getCssVariable('--cdm-nested-component-hover-bg'),
			'--cdm-time-info-bg': getCssVariable('--cdm-time-info-bg'),
			'--cdm-global-scrollbar-track': getCssVariable('--cdm-global-scrollbar-track')
		};
	};

	// 动态创建ECharts主题的函数
	const createChartTheme = () => {
		const cssVarMap = getCssVariables();

		return {
			// 背景色
			backgroundColor: 'transparent',

			// 全局文本样式
			textStyle: {
				color: cssVarMap['--cdm-text-primary'],
				fontFamily: 'Arial, sans-serif'
			},

			// 标题样式
			title: {
				textStyle: {
					color: cssVarMap['--cdm-text-primary'],
					fontWeight: 'bold'
				},
				subtextStyle: {
					color: cssVarMap['--cdm-text-secondary']
				}
			},

			// 图例样式
			legend: {
				textStyle: {
					color: cssVarMap['--cdm-text-primary']
				}
			},

			// 坐标轴样式
			axisLine: {
				lineStyle: {
					color: cssVarMap['--cdm-border-color']
				}
			},
			axisLabel: {
				color: cssVarMap['--cdm-text-secondary']
			},
			splitLine: {
				lineStyle: {
					color: cssVarMap['--cdm-border-color'],
					opacity: 0.3
				}
			},

			// 网格样式
			grid: {
				borderColor: cssVarMap['--cdm-border-color']
			},

			// 提示框样式
			tooltip: {
				backgroundColor: cssVarMap['--cdm-secondary-bg'],
				borderColor: cssVarMap['--cdm-border-color'],
				textStyle: {
					color: cssVarMap['--cdm-text-primary']
				},
				axisPointer: {
					lineStyle: {
						color: cssVarMap['--cdm-accent-color']
					},
					crossStyle: {
						color: cssVarMap['--cdm-accent-color']
					}
				}
			},

			// 工具箱
			toolbox: {
				iconStyle: {
					borderColor: cssVarMap['--cdm-accent-color']
				}
			},

			// 视觉映射
			visualMap: {
				textStyle: {
					color: cssVarMap['--cdm-text-primary']
				}
			},

			// 区域缩放
			dataZoom: {
				textStyle: {
					color: cssVarMap['--cdm-text-primary']
				},
				handleStyle: {
					color: cssVarMap['--cdm-accent-color']
				}
			}
		};
	};

	// 动态创建主题并注册
	const echartTheme = 'theme-cdm';
	echarts.registerTheme('theme-cdm', createChartTheme());

	return Control.extend("cdm.ui.control.EchartContainer", {
		metadata: {
			properties: {
				option: { type: "string", defaultValue: "" },
			},
			renderer: EchartContainerRenderer
		},

		/**
		 * @override
		 * @returns {void|undefined}
		 */
		init: function () {
			this._echart = null;
			// 绑定窗口大小调整事件
			window.addEventListener("resize", () => { this._handleWindowResize(); });
		},

		/**
		 * @override
		 * @param {jQuery.Event} oEvent <p>onAfterRendering event object</p>
		 * @returns {void|undefined}
		 */
		onAfterRendering: function (oEvent) {
			if (!this._echart) {
				this._echart = echarts.init(document.getElementById(this.getId() + "-echart"), echartTheme);
			}
		},

		/**
		 * 设置ECharts配置选项
		 * @param {Object} option - ECharts配置对象
		 */
		setOption: function (option) {
			if (this._echart && option) {
				this._echart.setOption(option);
			}
		},

		/**
		 * 处理窗口大小调整事件
		 * @private
		 */
		_handleWindowResize: function () {
			if (this._echart) {
				this._echart.resize();
			}
		},

		getEchart() {
			return this._echart;
		}
	});
});