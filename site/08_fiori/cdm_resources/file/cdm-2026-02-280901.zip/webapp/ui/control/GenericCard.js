sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/GenericCardRenderer",
], function (
    Control,
    GenericCardRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.GenericCard", {
        metadata: {
            properties: {
                // 选中
                selected: { type: "boolean", defaultValue: false },

                // 图片相关属性
                imageSrc: { type: "string", defaultValue: "" },
                imageAlt: { type: "string", defaultValue: "" },
                imageSize: { type: "string", defaultValue: "80px" },

                // 文本内容属性
                title: { type: "string", defaultValue: "" },
                subtitle: { type: "string", defaultValue: "" },
                description: { type: "string", defaultValue: "" },

                // 数值属性
                primaryLabel: { type: "string", defaultValue: "" },
                primaryValue: { type: "string", defaultValue: "0" },
                primaryUnit: { type: "string", defaultValue: "" },
                secondaryLabel: { type: "string", defaultValue: "" },
                secondaryValue: { type: "string", defaultValue: "" },
                secondaryUnit: { type: "string", defaultValue: "" },
                showUnits: { type: "boolean", defaultValue: true },

                // 样式属性
                cardColor: { type: "string", defaultValue: "var(--cdm-card-bg)" },
                titleColor: { type: "string", defaultValue: "var(--cdm-card-title-color)" },
                valueColor: { type: "string", defaultValue: "var(--cdm-color-accent)" },
                unitColor: { type: "string", defaultValue: "var(--cdm-color-text-primary)" },
                textColor: { type: "string", defaultValue: "var(--cdm-color-text-primary)" },
                titleSize: { type: "string", defaultValue: "0.8rem" },
                valueSize: { type: "string", defaultValue: "1rem" },
                unitSize: { type: "string", defaultValue: "1rem" },
                textSize: { type: "string", defaultValue: "0.8rem" },

                // 卡片尺寸
                cardWidth: { type: "string", defaultValue: "100%" },
                cardHeight: { type: "string", defaultValue: "auto" },

                // 布局控制
                layoutDirection: {
                    type: "string",
                    defaultValue: "horizontal",
                    values: ["horizontal", "vertical"]
                },
                contentLayout: {
                    type: "string",
                    defaultValue: "vertical",
                    values: ["horizontal", "vertical"]
                },
                contentAlignment: {
                    type: "string",
                    defaultValue: "left",
                    values: ["left", "center", "right"]
                },
                valuesLayout: {
                    type: "string",
                    defaultValue: "vertical",
                    values: ["horizontal", "vertical"]
                },
                backgroundStyle: {
                    type: "string",
                    defaultValue: "fill",
                    values: ["fill", "transparent"]
                },
                borderStyle: {
                    type: "string",
                    defaultValue: "normal",
                    values: ["normal", "none"]
                },
            },
            renderer: GenericCardRenderer
        },

        // 属性设置器
        setPrimaryValue: function (sValue) {
            var nValue = parseFloat(sValue) || 0;
            this.setProperty("primaryValue", nValue.toString());
            return this;
        },

        setSecondaryValue: function (sValue) {
            var nValue = parseFloat(sValue) || 0;
            this.setProperty("secondaryValue", nValue.toString());
            return this;
        },

        // 获取数值的方法
        getPrimaryValueNumber: function () {
            return parseFloat(this.getProperty("primaryValue")) || 0;
        },

        getSecondaryValueNumber: function () {
            return parseFloat(this.getProperty("secondaryValue")) || 0;
        },
    });
});