sap.ui.define([
    "sap/ui/core/Control",
    "cdm/ui/control/MonitorComponentRenderer",
], function (
    Control,
    MonitorComponentRenderer
) {
    "use strict";

    return Control.extend("cdm.ui.control.MonitorComponent", {
        metadata: {
            properties: {
                title: { type: "string", defaultValue: "" },
                gridArea: { type: "string", defaultValue: "" },
                borderStyle: {
                    type: "string",
                    defaultValue: "standard",
                    values: ["none", "standard", "transparent", "glow"]
                },
                contentFlexDirection: {
                    type: "string",
                    defaultValue: "column",
                    values: ["row", "column", "row-reverse", "column-reverse"]
                }
            },
            aggregations: {
                content: { type: "sap.ui.core.Control", multiple: true, defaultValue: null }
            },
            renderer: MonitorComponentRenderer
        }
    });
});